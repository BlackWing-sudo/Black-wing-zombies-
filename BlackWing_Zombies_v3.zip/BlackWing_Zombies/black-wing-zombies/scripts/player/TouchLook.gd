extends Control
## Camera look from ANYWHERE on the screen (joystick and buttons keep their own touches).
## Tracks the finger index, so moving with the joystick while looking works.

@export var sensitivity: float = 0.12

@onready var player: CharacterBody3D = get_parent()
@onready var head: Node3D = player.get_node("Head")

var look_index: int = -1
var last_touch_position: Vector2 = Vector2.ZERO
var pitch: float = 0.0


func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var touch := event as InputEventScreenTouch
		if touch.pressed:
			# newest finger wins (also recovers from a lost release, e.g. after pause)
			look_index = touch.index
			last_touch_position = touch.position
		elif touch.index == look_index:
			look_index = -1

	elif event is InputEventScreenDrag:
		var drag := event as InputEventScreenDrag
		if drag.index != look_index:
			return
		var delta: Vector2 = drag.position - last_touch_position
		last_touch_position = drag.position

		var sens: float = sensitivity
		var settings := get_node_or_null("/root/Settings")
		if settings != null:
			sens *= float(settings.get("look_sensitivity"))

		player.rotate_y(deg_to_rad(-delta.x * sens))
		pitch -= deg_to_rad(delta.y * sens)
		pitch = clampf(pitch, deg_to_rad(-80.0), deg_to_rad(80.0))
		head.rotation.x = pitch
