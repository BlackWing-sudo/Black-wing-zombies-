extends Node
## PlayerCombat - child of the Player (CharacterBody3D).
## Health, weapon slots (start: 1 weapon), perks, Pack-a-Punch, shooting, reload, recoil.
## Weapon numbers live in GameDB.gd.

const Sfx = preload("res://scripts/game/Sfx.gd")
const DB = preload("res://scripts/game/GameDB.gd")
const Models = preload("res://scripts/game/WeaponModels.gd")

signal health_changed(current: float, maximum: float)
signal damaged(amount: float)
signal died
signal revived
signal weapon_changed(weapon_name: String, index: int)
signal ammo_changed(mag: int, reserve: int)
signal reload_started(duration: float)
signal reload_ended
signal hit_confirmed(killed: bool, headshot: bool)
signal perks_changed(perk_ids: Array)

@export var max_health: float = 100.0
@export var regen_delay: float = 5.0
@export var regen_rate: float = 18.0
@export_flags_3d_physics var ray_mask: int = 5
@export var hold_position: Vector3 = Vector3(0.2, -0.2, -0.45)

var player: CharacterBody3D
var head: Node3D
var camera: Camera3D
var holder: Node3D
var muzzle_flash: MeshInstance3D
var muzzle_light: OmniLight3D

var health: float = 100.0
var dead: bool = false
var current: int = 0
var max_slots: int = 2
var slots: Array[Dictionary] = []
var perks: Dictionary = {}
var models: Dictionary = {}

var _stats: Dictionary = {}
var _mode: Node = null
var _invuln: float = 0.0
var _since_hurt: float = 999.0
var _fire_held: bool = false
var _fire_buffer: float = 0.0
var _cooldown: float = 0.0
var _reloading: bool = false
var _reload_left: float = 0.0
var _reload_total: float = 1.0
var _kick_back: float = 0.0
var _kick_rot: float = 0.0
var _raise: float = 0.0
var _bob_time: float = 0.0
var _flash_left: float = 0.0
var _sfx_pool: Array[AudioStreamPlayer] = []
var _sfx_next: int = 0
var _tracer_mat: StandardMaterial3D


func _ready() -> void:
	player = get_parent() as CharacterBody3D
	head = player.get_node("Head") as Node3D
	camera = head.get_node("Camera3D") as Camera3D
	player.add_to_group("player")

	slots.append(_new_slot("PISTOL"))   # round 1: ONE weapon only

	_tracer_mat = StandardMaterial3D.new()
	_tracer_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_tracer_mat.albedo_color = Color(1.0, 0.85, 0.45)

	_build_holder()
	for i in 6:
		var p := AudioStreamPlayer.new()
		p.bus = "SFX"
		add_child(p)
		_sfx_pool.append(p)

	health = max_health
	_refresh_stats()
	_apply_weapon()
	health_changed.emit(health, max_health)


# ------------------------------------------------------------------ public API

func set_fire_held(held: bool) -> void:
	if held and not _fire_held:
		_fire_buffer = 0.15
	_fire_held = held


func next_weapon() -> void:
	if dead or slots.size() < 2:
		return
	current = (current + 1) % slots.size()
	_after_slot_change()


func start_reload() -> void:
	if dead or _reloading:
		return
	var slot: Dictionary = slots[current]
	if int(slot["mag"]) >= int(_stats["mag"]) or int(slot["reserve"]) <= 0:
		return
	_reloading = true
	_reload_total = float(_stats["reload"])
	_reload_left = _reload_total
	reload_started.emit(_reload_total)
	_play("reload", -3.0, 1.0)


func has_weapon(id: String) -> bool:
	for s in slots:
		if String(s["id"]) == id:
			return true
	return false


func current_id() -> String:
	return String(slots[current]["id"])


func current_is_pap() -> bool:
	return bool(slots[current]["pap"])


# Buy / box: owned -> refill ammo, free slot -> add, full -> replace current.
func give_weapon(id: String) -> void:
	for i in slots.size():
		if String(slots[i]["id"]) == id:
			current = i
			_fill_slot(slots[i])
			_after_slot_change()
			return
	var slot: Dictionary = _new_slot(id)
	if slots.size() < max_slots:
		slots.append(slot)
		current = slots.size() - 1
	else:
		slots[current] = slot
	_after_slot_change()


func buy_ammo(id: String) -> void:
	for s in slots:
		if String(s["id"]) == id:
			_fill_slot(s)
	_refresh_stats()
	ammo_changed.emit(int(slots[current]["mag"]), int(slots[current]["reserve"]))


func upgrade_current() -> bool:
	var slot: Dictionary = slots[current]
	if bool(slot["pap"]):
		return false
	slot["pap"] = true
	_fill_slot(slot)
	_after_slot_change()
	return true


func refill_all() -> void:
	for s in slots:
		_fill_slot(s)
	ammo_changed.emit(int(slots[current]["mag"]), int(slots[current]["reserve"]))


func has_perk(id: String) -> bool:
	return perks.has(id)


func add_perk(id: String) -> void:
	if perks.has(id):
		return
	perks[id] = true
	match id:
		"JUGGERNOG":
			max_health = 250.0
			health = max_health
		"STAMIN_UP":
			player.set("move_speed", float(player.get("move_speed")) * 1.3)
		"MULE_KICK":
			max_slots = 3
	_refresh_stats()
	health_changed.emit(health, max_health)
	perks_changed.emit(perks.keys())


func take_damage(amount: float) -> void:
	if dead or _invuln > 0.0:
		return
	health = maxf(0.0, health - amount)
	_since_hurt = 0.0
	damaged.emit(amount)
	health_changed.emit(health, max_health)
	_play("player_hurt", -2.0, 1.0)
	if health <= 0.0:
		if perks.has("QUICK_REVIVE"):
			perks.erase("QUICK_REVIVE")
			health = max_health
			_invuln = 3.0
			health_changed.emit(health, max_health)
			perks_changed.emit(perks.keys())
			revived.emit()
		else:
			_die()


func refresh() -> void:
	health_changed.emit(health, max_health)
	perks_changed.emit(perks.keys())
	_apply_weapon()


# ------------------------------------------------------------------ slots / stats

func _new_slot(id: String) -> Dictionary:
	var base: Dictionary = DB.WEAPONS[id]
	return {"id": id, "mag": int(base["mag"]), "reserve": int(base["reserve"]), "pap": false}


func _compute_stats(slot: Dictionary) -> Dictionary:
	var base: Dictionary = DB.WEAPONS[String(slot["id"])]
	var s: Dictionary = base.duplicate()
	if bool(slot["pap"]):
		s["name"] = base["pap_name"]
		s["damage"] = float(base["damage"]) * DB.PAP_DAMAGE
		s["mag"] = int(round(float(base["mag"]) * DB.PAP_MAG))
		s["reserve"] = int(round(float(base["reserve"]) * DB.PAP_RESERVE))
	else:
		s["name"] = tr("W_" + String(slot["id"]))
	if perks.has("DOUBLE_TAP"):
		s["interval"] = float(s["interval"]) * 0.7
	if perks.has("SPEED_COLA"):
		s["reload"] = float(s["reload"]) * 0.5
	if perks.has("DEADSHOT"):
		s["spread"] = float(s["spread"]) * 0.35
		s["head"] = float(s["head"]) * 1.4
	return s


func _refresh_stats() -> void:
	_stats = _compute_stats(slots[current])


func _fill_slot(slot: Dictionary) -> void:
	var s: Dictionary = _compute_stats(slot)
	slot["mag"] = int(s["mag"])
	slot["reserve"] = int(s["reserve"])


func _after_slot_change() -> void:
	if _reloading:
		_reloading = false
		reload_ended.emit()
	_cooldown = 0.3
	_raise = 1.0
	_fire_buffer = 0.0
	_refresh_stats()
	_apply_weapon()


func _apply_weapon() -> void:
	var slot: Dictionary = slots[current]
	_refresh_stats()
	var key: String = String(slot["id"])
	if bool(slot["pap"]):
		key += "_PAP"
	if not models.has(key):
		var m := Node3D.new()
		m.name = key
		holder.add_child(m)
		Models.fill(m, String(slot["id"]), 1 if bool(slot["pap"]) else 0)
		models[key] = m
	for k in models:
		(models[k] as Node3D).visible = (String(k) == key)
	muzzle_flash.position = Vector3(0.0, 0.02, float(_stats["muzzle_z"]))
	muzzle_light.position = muzzle_flash.position + Vector3(0.0, 0.0, -0.1)
	weapon_changed.emit(String(_stats["name"]), current)
	ammo_changed.emit(int(slot["mag"]), int(slot["reserve"]))


# ------------------------------------------------------------------ loop

func _physics_process(delta: float) -> void:
	if dead:
		return
	_since_hurt += delta
	_invuln = maxf(0.0, _invuln - delta)
	_cooldown = maxf(0.0, _cooldown - delta)
	_fire_buffer = maxf(0.0, _fire_buffer - delta)

	if _reloading:
		_reload_left -= delta
		if _reload_left <= 0.0:
			_finish_reload()
	else:
		var wants_fire: bool = false
		if bool(_stats["auto"]):
			wants_fire = _fire_held
		else:
			wants_fire = _fire_buffer > 0.0
		if wants_fire and _cooldown <= 0.0:
			_fire()
			_fire_buffer = 0.0

	if health < max_health and _since_hurt >= regen_delay:
		health = minf(max_health, health + regen_rate * delta)
		health_changed.emit(health, max_health)


func _process(delta: float) -> void:
	if dead:
		return
	_update_view_model(delta)


# ------------------------------------------------------------------ shooting

func _insta_kill() -> bool:
	if _mode == null or not is_instance_valid(_mode):
		_mode = get_tree().get_first_node_in_group("zombie_mode")
	return _mode != null and bool(_mode.get("insta_kill"))


func _fire() -> void:
	var slot: Dictionary = slots[current]
	if int(slot["mag"]) <= 0:
		_cooldown = 0.3
		_play("empty", -4.0, 1.0)
		if int(slot["reserve"]) > 0:
			start_reload()
		return

	slot["mag"] = int(slot["mag"]) - 1
	_cooldown = float(_stats["interval"])
	ammo_changed.emit(int(slot["mag"]), int(slot["reserve"]))

	var pellets: int = int(_stats["pellets"])
	var max_range: float = float(_stats["range"])
	var insta: bool = _insta_kill()
	var any_hit: bool = false
	var any_kill: bool = false
	var any_head: bool = false
	var origin: Vector3 = camera.global_position
	var muzzle_pos: Vector3 = muzzle_flash.global_position

	for i in pellets:
		var dir: Vector3 = _spread_direction(float(_stats["spread"]))
		var hit: Dictionary = _raycast(origin, dir, max_range)
		var end_pos: Vector3 = origin + dir * minf(max_range, 40.0)
		if not hit.is_empty():
			end_pos = hit["position"]
			var collider := hit["collider"] as Node3D
			var is_zombie: bool = collider != null and collider.is_in_group("zombie") and collider.has_method("take_damage")
			if is_zombie:
				var is_head: bool = end_pos.y > collider.global_position.y + 1.45
				var dmg: float = float(_stats["damage"])
				if is_head:
					dmg *= float(_stats["head"])
				if insta:
					dmg = 99999.0
				var killed: bool = bool(collider.call("take_damage", dmg, is_head, end_pos, dir))
				any_hit = true
				any_kill = any_kill or killed
				any_head = any_head or is_head
				if i < 3:
					_spawn_burst(end_pos, -dir, Color(0.6, 0.04, 0.04), 8)
			elif i < 3:
				var normal: Vector3 = hit["normal"]
				_spawn_burst(end_pos, normal, Color(0.95, 0.8, 0.5), 4)
		if i == 0:
			_spawn_tracer(muzzle_pos, end_pos)

	if any_hit:
		hit_confirmed.emit(any_kill, any_head)

	var kick: float = float(_stats["kick"])
	_kick_back = minf(_kick_back + kick, 0.3)
	_kick_rot = minf(_kick_rot + kick * 1.5, 0.4)
	_flash_left = 0.05
	_play(String(_stats["sound"]), -2.0, randf_range(0.96, 1.04))

	if int(slot["mag"]) == 0 and int(slot["reserve"]) > 0:
		start_reload()


func _spread_direction(spread_deg: float) -> Vector3:
	var b: Basis = camera.global_transform.basis
	var dir: Vector3 = -b.z
	if spread_deg <= 0.0:
		return dir
	var ang: float = randf() * TAU
	var rad: float = deg_to_rad(spread_deg) * sqrt(randf())
	var offset: Vector3 = (b.x * cos(ang) + b.y * sin(ang)) * tan(rad)
	return (dir + offset).normalized()


func _raycast(origin: Vector3, dir: Vector3, max_range: float) -> Dictionary:
	var space: PhysicsDirectSpaceState3D = player.get_world_3d().direct_space_state
	var query := PhysicsRayQueryParameters3D.create(origin, origin + dir * max_range, ray_mask)
	query.exclude = [player.get_rid()]
	return space.intersect_ray(query)


func _finish_reload() -> void:
	_reloading = false
	var slot: Dictionary = slots[current]
	var need: int = int(_stats["mag"]) - int(slot["mag"])
	var take: int = mini(need, int(slot["reserve"]))
	slot["mag"] = int(slot["mag"]) + take
	slot["reserve"] = int(slot["reserve"]) - take
	ammo_changed.emit(int(slot["mag"]), int(slot["reserve"]))
	reload_ended.emit()


func _die() -> void:
	dead = true
	_fire_held = false
	_fire_buffer = 0.0
	if _reloading:
		_reloading = false
		reload_ended.emit()
	holder.visible = false
	muzzle_light.visible = false
	player.set_physics_process(false)
	player.velocity = Vector3.ZERO
	var look := player.get_node_or_null("TouchLook") as Control
	if look != null:
		look.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var tween := create_tween()
	tween.set_parallel(true)
	tween.tween_property(head, "position:y", 0.35, 0.8).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tween.tween_property(camera, "rotation:z", 0.7, 0.8)
	died.emit()


# ------------------------------------------------------------------ view model / fx

func _build_holder() -> void:
	holder = Node3D.new()
	holder.name = "WeaponHolder"
	holder.position = hold_position
	camera.add_child(holder)

	muzzle_flash = MeshInstance3D.new()
	var fm := SphereMesh.new()
	fm.radius = 0.05
	fm.height = 0.1
	muzzle_flash.mesh = fm
	var fmat := StandardMaterial3D.new()
	fmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	fmat.albedo_color = Color(1.0, 0.85, 0.4)
	muzzle_flash.material_override = fmat
	muzzle_flash.visible = false
	holder.add_child(muzzle_flash)

	muzzle_light = OmniLight3D.new()
	muzzle_light.light_color = Color(1.0, 0.75, 0.4)
	muzzle_light.light_energy = 2.5
	muzzle_light.omni_range = 6.0
	muzzle_light.visible = false
	holder.add_child(muzzle_light)


func _update_view_model(delta: float) -> void:
	var k: float = 1.0 - exp(-14.0 * delta)
	_kick_back = lerpf(_kick_back, 0.0, k)
	_kick_rot = lerpf(_kick_rot, 0.0, k)
	_raise = lerpf(_raise, 0.0, 1.0 - exp(-9.0 * delta))

	var reload_amt: float = 0.0
	if _reloading and _reload_total > 0.0:
		var t: float = 1.0 - (_reload_left / _reload_total)
		reload_amt = sin(clampf(t, 0.0, 1.0) * PI)

	var speed: float = Vector2(player.velocity.x, player.velocity.z).length()
	var moving: float = clampf(speed / 4.0, 0.0, 1.0)
	_bob_time += delta * (2.0 + speed * 2.2)
	var bob := Vector3(sin(_bob_time) * 0.012, absf(cos(_bob_time)) * 0.014, 0.0) * moving

	holder.position = hold_position + bob + Vector3(0.0, -0.22 * _raise - 0.2 * reload_amt, _kick_back)
	holder.rotation.x = _kick_rot - 0.8 * reload_amt - 0.5 * _raise
	camera.rotation.x = _kick_rot * 0.15

	if _flash_left > 0.0:
		_flash_left -= delta
		muzzle_flash.visible = true
		muzzle_flash.scale = Vector3.ONE * randf_range(0.7, 1.4)
		muzzle_light.visible = true
	else:
		muzzle_flash.visible = false
		muzzle_light.visible = false


func _spawn_tracer(from: Vector3, to: Vector3) -> void:
	var length: float = from.distance_to(to)
	if length < 0.5:
		return
	var tracer := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.012, 0.012, length)
	tracer.mesh = bm
	tracer.material_override = _tracer_mat
	tracer.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	get_tree().current_scene.add_child(tracer)
	tracer.global_position = (from + to) * 0.5
	var up: Vector3 = Vector3.UP
	if absf((to - from).normalized().y) > 0.99:
		up = Vector3.RIGHT
	tracer.look_at(to, up)
	get_tree().create_timer(0.05).timeout.connect(tracer.queue_free)


func _spawn_burst(pos: Vector3, normal: Vector3, color: Color, amount: int) -> void:
	var p := CPUParticles3D.new()
	p.one_shot = true
	p.amount = amount
	p.lifetime = 0.35
	p.explosiveness = 1.0
	p.direction = normal
	p.spread = 55.0
	p.initial_velocity_min = 1.5
	p.initial_velocity_max = 3.5
	p.gravity = Vector3(0.0, -9.0, 0.0)
	var sm := SphereMesh.new()
	sm.radius = 0.025
	sm.height = 0.05
	sm.radial_segments = 4
	sm.rings = 2
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = color
	sm.material = mat
	p.mesh = sm
	get_tree().current_scene.add_child(p)
	p.global_position = pos
	p.emitting = true
	p.finished.connect(p.queue_free)


func _play(sound_name: String, volume_db: float, pitch: float) -> void:
	var stream: AudioStream = Sfx.get_sound(sound_name)
	if stream == null or _sfx_pool.is_empty():
		return
	var p: AudioStreamPlayer = _sfx_pool[_sfx_next]
	_sfx_next = (_sfx_next + 1) % _sfx_pool.size()
	p.stream = stream
	p.volume_db = volume_db
	p.pitch_scale = pitch
	p.play()
