extends CharacterBody3D
## Zombie
## Chases the player (navmesh if it was baked, otherwise a straight line) and
## attacks in melee. The look is a blocky placeholder built in code.
## To use your own model: add a child Node3D named "Visual" in Zombie.tscn
## (the placeholder is only built when there is no "Visual" node).

const Sfx = preload("res://scripts/game/Sfx.gd")

signal died(zombie: Node3D, headshot: bool)
signal stuck(zombie: Node3D)

@export var max_health: float = 100.0
@export var move_speed: float = 2.0
@export var attack_damage: float = 20.0
@export var attack_range: float = 1.5
@export var attack_interval: float = 1.1
@export var gravity: float = 18.0

var target: Node3D = null
var use_navigation: bool = false
var active: bool = true
var health: float = 100.0
var dead: bool = false
var rising: bool = true

var nav_agent: NavigationAgent3D
var visual: Node3D
var arm_l: Node3D
var arm_r: Node3D
var leg_l: Node3D
var leg_r: Node3D
var meshes: Array[MeshInstance3D] = []

var _flash_mat: StandardMaterial3D
var _target_combat: Node = null
var _repath_left: float = 0.0
var _attack_cd: float = 0.0
var _attacking: bool = false
var _attack_time: float = 0.0
var _hit_done: bool = false
var _anim_time: float = 0.0
var _groan_left: float = 3.0
var _stuck_timer: float = 0.0
var _stuck_seconds: int = 0
var _last_pos: Vector3 = Vector3.ZERO
var _voice: AudioStreamPlayer3D
var _hit_sfx: AudioStreamPlayer3D


# Called by the game mode BEFORE the zombie is added to the scene.
func configure(p_target: Node3D, p_health: float, p_speed: float, p_damage: float, p_use_nav: bool) -> void:
	target = p_target
	max_health = p_health
	health = p_health
	move_speed = p_speed
	attack_damage = p_damage
	use_navigation = p_use_nav


func _ready() -> void:
	add_to_group("zombie")
	collision_layer = 4   # layer 3 = zombies
	collision_mask = 5    # world/player (1) + other zombies (4)
	health = max_health

	nav_agent = get_node_or_null("NavigationAgent3D") as NavigationAgent3D
	if nav_agent == null:
		nav_agent = NavigationAgent3D.new()
		nav_agent.path_desired_distance = 0.6
		nav_agent.target_desired_distance = 1.2
		nav_agent.radius = 0.4
		nav_agent.height = 1.8
		add_child(nav_agent)

	visual = get_node_or_null("Visual") as Node3D
	if visual == null:
		_build_placeholder_visual()

	_flash_mat = StandardMaterial3D.new()
	_flash_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_flash_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_flash_mat.albedo_color = Color(1.0, 1.0, 1.0, 0.55)

	_setup_audio()
	_groan_left = randf_range(2.0, 6.0)
	begin_rise()


func set_active(value: bool) -> void:
	active = value
	if not value:
		velocity = Vector3.ZERO


# Zombie climbs out of the ground (also used again after a stuck-teleport).
func begin_rise() -> void:
	rising = true
	_stuck_seconds = 0
	_last_pos = global_position
	if visual == null:
		rising = false
		return
	visual.position.y = -1.9
	var tween := create_tween()
	tween.tween_property(visual, "position:y", 0.0, 1.0).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	tween.tween_callback(_finish_rise)


func _finish_rise() -> void:
	rising = false


# ---------------------------------------------------------------------------
# AI
# ---------------------------------------------------------------------------

func _physics_process(delta: float) -> void:
	if dead or not active:
		return

	if not is_on_floor():
		velocity.y -= gravity * delta
	else:
		velocity.y = 0.0

	var move_dir := Vector3.ZERO
	var face_dir := Vector3.ZERO

	if is_instance_valid(target):
		var to_target: Vector3 = target.global_position - global_position
		to_target.y = 0.0
		var dist: float = to_target.length()
		face_dir = to_target

		if not rising:
			_update_attack(delta, dist)
			if dist > attack_range * 0.75 and not _attacking:
				move_dir = _chase_direction(delta, to_target)
				if dist > 3.0 and move_dir.length() > 0.01:
					face_dir = move_dir

	if face_dir.length() > 0.01:
		var yaw: float = atan2(-face_dir.x, -face_dir.z)
		rotation.y = lerp_angle(rotation.y, yaw, minf(1.0, delta * 9.0))

	velocity.x = move_dir.x * move_speed
	velocity.z = move_dir.z * move_speed
	move_and_slide()

	_animate(delta, Vector2(velocity.x, velocity.z).length())
	_update_groan(delta)
	_check_stuck(delta)


func _chase_direction(delta: float, to_target: Vector3) -> Vector3:
	var direct: Vector3 = to_target.normalized()
	if not use_navigation or nav_agent == null or to_target.length() < 3.0:
		return direct

	_repath_left -= delta
	if _repath_left <= 0.0:
		_repath_left = 0.3
		nav_agent.target_position = target.global_position

	if nav_agent.is_navigation_finished():
		return direct

	var next_pos: Vector3 = nav_agent.get_next_path_position()
	var dir: Vector3 = next_pos - global_position
	dir.y = 0.0
	if dir.length() < 0.05:
		return direct
	return dir.normalized()


func _update_attack(delta: float, dist: float) -> void:
	_attack_cd = maxf(0.0, _attack_cd - delta)

	if _attacking:
		_attack_time += delta
		if not _hit_done and _attack_time >= 0.35:
			_hit_done = true
			if is_instance_valid(target) and global_position.distance_to(target.global_position) <= attack_range + 0.5:
				_deal_damage()
		if _attack_time >= 0.7:
			_attacking = false
		return

	if dist <= attack_range and _attack_cd <= 0.0:
		_attacking = true
		_attack_time = 0.0
		_hit_done = false
		_attack_cd = attack_interval


func _deal_damage() -> void:
	if _target_combat == null:
		_target_combat = target.get_node_or_null("PlayerCombat")
	if _target_combat != null and _target_combat.has_method("take_damage"):
		_target_combat.call("take_damage", attack_damage)


func _check_stuck(delta: float) -> void:
	_stuck_timer += delta
	if _stuck_timer < 1.0:
		return
	_stuck_timer = 0.0

	if global_position.y < -8.0:
		stuck.emit(self)
		return

	if rising or _attacking or not is_instance_valid(target):
		_last_pos = global_position
		_stuck_seconds = 0
		return

	var moved: float = global_position.distance_to(_last_pos)
	_last_pos = global_position
	var far: bool = global_position.distance_to(target.global_position) > attack_range + 1.0
	if moved < 0.2 and far:
		_stuck_seconds += 1
	else:
		_stuck_seconds = 0

	if _stuck_seconds >= 6:
		_stuck_seconds = 0
		stuck.emit(self)


# ---------------------------------------------------------------------------
# DAMAGE / DEATH
# ---------------------------------------------------------------------------

# Returns true if this hit killed the zombie.
func take_damage(amount: float, headshot: bool, _hit_pos: Vector3, _hit_dir: Vector3) -> bool:
	if dead:
		return false
	health -= amount
	_flash()
	_play_3d(_hit_sfx, "zombie_hit", -4.0)
	if health <= 0.0:
		_die(headshot)
		return true
	return false


func _die(headshot: bool) -> void:
	dead = true
	remove_from_group("zombie")
	collision_layer = 0
	collision_mask = 0
	velocity = Vector3.ZERO
	_play_3d(_voice, "zombie_die", -2.0)
	died.emit(self, headshot)

	if visual == null:
		queue_free()
		return
	var tween := create_tween()
	tween.tween_property(visual, "rotation:x", deg_to_rad(88.0), 0.45).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	tween.tween_interval(2.5)
	tween.tween_property(visual, "position:y", -0.7, 1.0)
	tween.tween_callback(queue_free)


func _flash() -> void:
	for m in meshes:
		if is_instance_valid(m):
			m.material_overlay = _flash_mat
	get_tree().create_timer(0.06).timeout.connect(_clear_flash)


func _clear_flash() -> void:
	for m in meshes:
		if is_instance_valid(m):
			m.material_overlay = null


# ---------------------------------------------------------------------------
# ANIMATION (procedural)
# ---------------------------------------------------------------------------

func _animate(delta: float, speed: float) -> void:
	if visual == null:
		return
	_anim_time += delta * (3.0 + speed * 2.5)
	var swing: float = sin(_anim_time) * clampf(speed / 2.0, 0.0, 1.0) * 0.7

	if leg_l != null and leg_r != null:
		leg_l.rotation.x = swing
		leg_r.rotation.x = -swing

	if arm_l != null and arm_r != null:
		var attack_swing: float = 0.0
		if _attacking:
			attack_swing = sin(_attack_time / 0.7 * TAU) * 0.6
		# +1.35 rad = arms stretched forward (zombie pose)
		arm_l.rotation.x = 1.35 - swing * 0.3 + attack_swing
		arm_r.rotation.x = 1.35 + swing * 0.3 + attack_swing

	if not dead and not rising:
		visual.rotation.z = sin(_anim_time * 0.5) * 0.05


func _build_placeholder_visual() -> void:
	visual = Node3D.new()
	visual.name = "Visual"
	add_child(visual)

	var tint: float = randf_range(-0.06, 0.06)
	var skin := _mat(Color(0.38 + tint, 0.52 + tint, 0.32 + tint))
	var shirt := _mat(Color(0.22 + tint, 0.2, 0.28))
	var pants := _mat(Color(0.14, 0.15, 0.2 + tint))
	var eyes := _mat(Color(1.0, 0.1, 0.1))
	eyes.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED

	_part(visual, Vector3(0.5, 0.62, 0.26), Vector3(0.0, 1.12, 0.0), shirt)

	var head_mesh: MeshInstance3D = _part(visual, Vector3(0.28, 0.3, 0.28), Vector3(0.0, 1.62, 0.0), skin)
	_part(head_mesh, Vector3(0.05, 0.04, 0.02), Vector3(-0.07, 0.03, -0.145), eyes)
	_part(head_mesh, Vector3(0.05, 0.04, 0.02), Vector3(0.07, 0.03, -0.145), eyes)

	arm_l = Node3D.new()
	arm_l.position = Vector3(-0.34, 1.4, 0.0)
	visual.add_child(arm_l)
	_part(arm_l, Vector3(0.14, 0.6, 0.14), Vector3(0.0, -0.28, 0.0), skin)

	arm_r = Node3D.new()
	arm_r.position = Vector3(0.34, 1.4, 0.0)
	visual.add_child(arm_r)
	_part(arm_r, Vector3(0.14, 0.6, 0.14), Vector3(0.0, -0.28, 0.0), skin)

	leg_l = Node3D.new()
	leg_l.position = Vector3(-0.13, 0.82, 0.0)
	visual.add_child(leg_l)
	_part(leg_l, Vector3(0.18, 0.8, 0.2), Vector3(0.0, -0.4, 0.0), pants)

	leg_r = Node3D.new()
	leg_r.position = Vector3(0.13, 0.82, 0.0)
	visual.add_child(leg_r)
	_part(leg_r, Vector3(0.18, 0.8, 0.2), Vector3(0.0, -0.4, 0.0), pants)


func _mat(color: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.9
	return m


func _part(parent: Node3D, box_size: Vector3, pos: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = box_size
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	parent.add_child(mi)
	meshes.append(mi)
	return mi


# ---------------------------------------------------------------------------
# SOUND
# ---------------------------------------------------------------------------

func _setup_audio() -> void:
	_voice = AudioStreamPlayer3D.new()
	_voice.bus = "SFX"
	_voice.max_distance = 35.0
	_voice.unit_size = 6.0
	_voice.position = Vector3(0.0, 1.5, 0.0)
	add_child(_voice)

	_hit_sfx = AudioStreamPlayer3D.new()
	_hit_sfx.bus = "SFX"
	_hit_sfx.max_distance = 35.0
	_hit_sfx.unit_size = 6.0
	_hit_sfx.position = Vector3(0.0, 1.2, 0.0)
	add_child(_hit_sfx)


func _update_groan(delta: float) -> void:
	_groan_left -= delta
	if _groan_left <= 0.0:
		_groan_left = randf_range(4.0, 9.0)
		_play_3d(_voice, "zombie_groan", -6.0)


func _play_3d(p: AudioStreamPlayer3D, sound_name: String, volume_db: float) -> void:
	if p == null:
		return
	var stream: AudioStream = Sfx.get_sound(sound_name)
	if stream == null:
		return
	p.stream = stream
	p.volume_db = volume_db
	p.pitch_scale = randf_range(0.9, 1.1)
	p.play()
