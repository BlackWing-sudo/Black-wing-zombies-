extends CanvasLayer
## In-game pause menu: Resume / Restart / Settings / Main Menu. Really pauses the tree.

signal closed

const SettingsPanel = preload("res://scripts/ui/SettingsPanel.gd")

var _overlay: ColorRect


func _ready() -> void:
	layer = 30
	process_mode = Node.PROCESS_MODE_ALWAYS
	get_tree().paused = true

	_overlay = ColorRect.new()
	_overlay.color = Color(0.0, 0.0, 0.0, 0.8)
	_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(_overlay)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_overlay.add_child(center)
	var box := VBoxContainer.new()
	box.custom_minimum_size = Vector2(420.0, 0.0)
	box.add_theme_constant_override("separation", 16)
	center.add_child(box)

	var title := Label.new()
	title.text = tr("PAUSE")
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 52)
	title.add_theme_color_override("font_color", Color(0.95, 0.8, 0.3))
	box.add_child(title)

	box.add_child(_button("RESUME", _on_resume))
	box.add_child(_button("RESTART", _on_restart))
	box.add_child(_button("SETTINGS", _on_settings))
	box.add_child(_button("MAIN_MENU", _on_menu))


func _button(key: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = tr(key)
	b.custom_minimum_size = Vector2(0.0, 70.0)
	b.add_theme_font_size_override("font_size", 30)
	b.pressed.connect(cb)
	return b


func _on_resume() -> void:
	get_tree().paused = false
	closed.emit()
	queue_free()


func _on_restart() -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()


func _on_settings() -> void:
	var panel := SettingsPanel.new()
	add_child(panel)


func _on_menu() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file("res://scenes/menu/MainMenu.tscn")
