extends ColorRect
## Credits overlay: developer + Special Thanks. Emits `closed` on BACK.

signal closed


func _ready() -> void:
	color = Color(0.03, 0.03, 0.04, 0.97)
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP

	var scroll := ScrollContainer.new()
	scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	scroll.offset_left = 80.0
	scroll.offset_right = -80.0
	scroll.offset_top = 30.0
	scroll.offset_bottom = -30.0
	add_child(scroll)

	var box := VBoxContainer.new()
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.add_theme_constant_override("separation", 18)
	scroll.add_child(box)

	box.add_child(_line(tr("CR_TITLE"), 46, Color(0.95, 0.8, 0.3)))
	box.add_child(_line("BlackWing Zombies", 30, Color.WHITE))
	box.add_child(_line(tr("CR_DEV"), 22, Color(0.7, 0.7, 0.75)))
	box.add_child(_line(tr("CR_DEV_NAME"), 34, Color.WHITE))
	box.add_child(_line("", 10, Color.WHITE))
	box.add_child(_line(tr("CR_THANKS") + "  —  شكر خاص" if TranslationServer.get_locale().begins_with("en") else tr("CR_THANKS"), 34, Color(0.95, 0.8, 0.3)))
	box.add_child(_line(tr("CR_FRIEND"), 32, Color.WHITE))
	for code in ["ar", "en"]:
		var tr_obj: Translation = TranslationServer.get_translation_object(code)
		var ded := _line(String(tr_obj.get_message("CR_DEDICATION")), 24, Color(0.85, 0.85, 0.9))
		ded.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		ded.custom_minimum_size = Vector2(700.0, 0.0)
		box.add_child(ded)
	box.add_child(_line("", 10, Color.WHITE))
	box.add_child(_line(tr("CR_ASSETS"), 20, Color(0.6, 0.6, 0.65)))

	var back := Button.new()
	back.text = tr("BACK")
	back.custom_minimum_size = Vector2(260.0, 64.0)
	back.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	back.add_theme_font_size_override("font_size", 28)
	back.pressed.connect(_on_back)
	box.add_child(back)


func _line(text: String, px: int, col: Color) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", px)
	l.add_theme_color_override("font_color", col)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l


func _on_back() -> void:
	closed.emit()
	queue_free()
