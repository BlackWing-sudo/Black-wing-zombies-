extends ColorRect
## Settings overlay (volume, effects volume, camera sensitivity, language).
## Works from the main menu and from the pause menu. Emits `closed` on BACK.

signal closed

var _s: Node
var _title: Label
var _lbl_master: Label
var _lbl_sfx: Label
var _lbl_sens: Label
var _lbl_lang: Label
var _back: Button


func _ready() -> void:
	_s = get_node_or_null("/root/Settings")
	color = Color(0.03, 0.03, 0.04, 0.96)
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var box := VBoxContainer.new()
	box.custom_minimum_size = Vector2(760.0, 0.0)
	box.add_theme_constant_override("separation", 22)
	center.add_child(box)

	_title = _label(44, Color(0.95, 0.8, 0.3))
	box.add_child(_title)
	_lbl_master = _label(26, Color.WHITE)
	box.add_child(_lbl_master)
	box.add_child(_slider(0.0, 1.0, "master_volume", "set_master"))
	_lbl_sfx = _label(26, Color.WHITE)
	box.add_child(_lbl_sfx)
	box.add_child(_slider(0.0, 1.0, "sfx_volume", "set_sfx"))
	_lbl_sens = _label(26, Color.WHITE)
	box.add_child(_lbl_sens)
	box.add_child(_slider(0.3, 2.5, "look_sensitivity", "set_sensitivity"))
	_lbl_lang = _label(26, Color.WHITE)
	box.add_child(_lbl_lang)

	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 24)
	box.add_child(row)
	row.add_child(_lang_button("English", "en"))
	row.add_child(_lang_button("العربية", "ar"))

	_back = Button.new()
	_back.custom_minimum_size = Vector2(260.0, 64.0)
	_back.add_theme_font_size_override("font_size", 28)
	_back.pressed.connect(_on_back)
	box.add_child(_back)

	if _s != null:
		_s.connect("changed", _refresh)
	_refresh()


func _label(px: int, col: Color) -> Label:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", px)
	l.add_theme_color_override("font_color", col)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	return l


func _slider(lo: float, hi: float, prop: String, setter: String) -> HSlider:
	var sl := HSlider.new()
	sl.min_value = lo
	sl.max_value = hi
	sl.step = 0.05
	sl.custom_minimum_size = Vector2(0.0, 40.0)
	if _s != null:
		sl.value = float(_s.get(prop))
		sl.value_changed.connect(func(v: float) -> void: _s.call(setter, v))
	return sl


func _lang_button(text: String, code: String) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(220.0, 60.0)
	b.add_theme_font_size_override("font_size", 26)
	b.pressed.connect(func() -> void:
		if _s != null:
			_s.call("set_language", code))
	return b


func _refresh() -> void:
	_title.text = tr("SETTINGS")
	_lbl_master.text = tr("SET_MASTER")
	_lbl_sfx.text = tr("SET_SFX")
	_lbl_sens.text = tr("SET_SENS")
	_lbl_lang.text = tr("SET_LANG")
	_back.text = tr("BACK")


func _on_back() -> void:
	closed.emit()
	queue_free()
