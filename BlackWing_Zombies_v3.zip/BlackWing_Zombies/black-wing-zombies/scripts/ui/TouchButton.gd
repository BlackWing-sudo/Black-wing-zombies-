extends Control
## Multi-touch circular button.
## Works at the same time as the joystick and the look finger
## (a normal Button can lose the touch when another finger is already down).
##
## Read `is_down`, or connect to the `pressed` / `released` signals.

signal pressed
signal released

@export var label_text: String = ""
@export var font_size: int = 20
@export var base_color: Color = Color(0.05, 0.05, 0.06, 0.5)
@export var ring_color: Color = Color(0.85, 0.2, 0.2, 0.95)

var is_down: bool = false

var _touch_index: int = -1


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	visibility_changed.connect(_on_visibility_changed)


func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var touch := event as InputEventScreenTouch
		if touch.pressed:
			if _touch_index == -1 and _inside_circle(touch.position):
				_touch_index = touch.index
				_set_down(true)
				accept_event()
		elif touch.index == _touch_index:
			_touch_index = -1
			_set_down(false)
			accept_event()

	elif event is InputEventMouseButton:
		# Real mouse only (for testing on PC). Touch is handled above.
		var mouse := event as InputEventMouseButton
		if mouse.device == InputEvent.DEVICE_ID_EMULATION:
			return
		if mouse.button_index == MOUSE_BUTTON_LEFT:
			_set_down(mouse.pressed)
			accept_event()


func release() -> void:
	_touch_index = -1
	_set_down(false)


func _inside_circle(point: Vector2) -> bool:
	var center: Vector2 = size * 0.5
	var radius: float = minf(size.x, size.y) * 0.5
	return point.distance_to(center) <= radius


func _set_down(value: bool) -> void:
	if is_down == value:
		return
	is_down = value
	queue_redraw()
	if value:
		pressed.emit()
	else:
		released.emit()


func _on_visibility_changed() -> void:
	if not is_visible_in_tree():
		_touch_index = -1
		_set_down(false)


func _draw() -> void:
	var center: Vector2 = size * 0.5
	var radius: float = minf(size.x, size.y) * 0.5

	var fill: Color = base_color
	if is_down:
		fill = Color(ring_color.r, ring_color.g, ring_color.b, 0.55)

	draw_circle(center, radius - 2.0, fill)
	draw_arc(center, radius - 3.0, 0.0, TAU, 48, ring_color, 3.0, true)

	if label_text != "":
		var font: Font = ThemeDB.fallback_font
		var text_size: Vector2 = font.get_string_size(label_text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size)
		var baseline_y: float = center.y + (font.get_ascent(font_size) - font.get_descent(font_size)) * 0.5
		draw_string(
			font,
			Vector2(center.x - text_size.x * 0.5, baseline_y),
			label_text,
			HORIZONTAL_ALIGNMENT_LEFT,
			-1,
			font_size,
			Color(1, 1, 1, 0.95)
		)
