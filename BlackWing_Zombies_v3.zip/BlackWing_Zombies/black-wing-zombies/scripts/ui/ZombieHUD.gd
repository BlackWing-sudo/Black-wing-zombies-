extends CanvasLayer
## ZombieHUD - built from code. Gameplay layout is always left-to-right (even in Arabic);
## only the text changes language. Positions: search "_place(" / "_make_button(".

const TouchButton = preload("res://scripts/ui/TouchButton.gd")
const PauseMenu = preload("res://scripts/ui/PauseMenu.gd")
const DB = preload("res://scripts/game/GameDB.gd")

var mode: Node
var combat: Node
var interactor: Node

var root: Control
var health_bar: ProgressBar
var health_label: Label
var round_label: Label
var remaining_label: Label
var points_label: Label
var weapon_label: Label
var ammo_label: Label
var message_label: Label
var status_label: Label
var prompt_label: Label
var reload_bar: ProgressBar
var crosshair: Control
var hit_marker: Control
var hurt_flash: ColorRect
var screen_flash_rect: ColorRect
var perk_row: HBoxContainer
var game_over_panel: ColorRect
var game_over_round: Label
var game_over_points: Label

var fire_right: Control
var fire_left: Control
var reload_button: Control
var switch_button: Control
var use_button: Control
var pause_button: Control

var _round: int = 0
var _remaining: int = 0
var _points: int = DB.START_POINTS
var _go_round: int = 0
var _go_points: int = 0
var _msg_tween: Tween
var _reload_tween: Tween
var _pause_menu: Node = null


func _ready() -> void:
	layer = 5
	mode = get_node_or_null("../ZombieMode")
	interactor = get_node_or_null("../Interactor")
	var player := get_node_or_null("../Player")
	if player != null:
		combat = player.get_node_or_null("PlayerCombat")
	_build_ui()
	_connect_signals()
	if combat != null:
		combat.call("refresh")
	var settings := get_node_or_null("/root/Settings")
	if settings != null:
		settings.connect("changed", _update_texts)
	_update_texts()


func _process(_delta: float) -> void:
	if combat == null:
		return
	var held: bool = bool(fire_right.get("is_down")) or bool(fire_left.get("is_down"))
	combat.call("set_fire_held", held)


func _update_texts() -> void:
	round_label.text = (tr("HUD_ROUND") % _round) if _round > 0 else ""
	remaining_label.text = (tr("HUD_ZOMBIES") % _remaining) if _round > 0 else ""
	points_label.text = tr("HUD_POINTS") % _points
	fire_right.set("label_text", tr("HUD_FIRE"))
	fire_left.set("label_text", tr("HUD_FIRE"))
	reload_button.set("label_text", tr("HUD_RELOAD"))
	switch_button.set("label_text", tr("HUD_SWITCH"))
	use_button.set("label_text", tr("HUD_USE"))
	for b in [fire_right, fire_left, reload_button, switch_button, use_button]:
		(b as Control).queue_redraw()
	game_over_round.text = tr("OVER_ROUND") % _go_round
	game_over_points.text = tr("OVER_POINTS") % _go_points
	if combat != null:
		combat.call("refresh")


# ------------------------------------------------------------------ build

func _build_ui() -> void:
	root = Control.new()
	root.name = "Root"
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.layout_direction = Control.LAYOUT_DIRECTION_LTR
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(root)

	hurt_flash = _full_rect(Color(0.8, 0.0, 0.0, 0.0))
	screen_flash_rect = _full_rect(Color(1.0, 1.0, 1.0, 0.0))

	health_bar = ProgressBar.new()
	health_bar.show_percentage = false
	health_bar.max_value = 100.0
	health_bar.value = 100.0
	health_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	health_bar.add_theme_stylebox_override("background", _flat(Color(0.05, 0.05, 0.05, 0.7), Color(0.35, 0.06, 0.06, 0.9)))
	health_bar.add_theme_stylebox_override("fill", _flat(Color(0.75, 0.1, 0.1, 0.95), Color(0, 0, 0, 0)))
	_rect(health_bar, 0.0, 0.0, 0.0, 0.0, 24.0, 20.0, 304.0, 46.0)
	root.add_child(health_bar)

	health_label = _make_label("100", 20, Color.WHITE)
	health_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	health_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_rect(health_label, 0.0, 0.0, 0.0, 0.0, 24.0, 20.0, 304.0, 46.0)
	root.add_child(health_label)

	perk_row = HBoxContainer.new()
	perk_row.add_theme_constant_override("separation", 6)
	perk_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_rect(perk_row, 0.0, 0.0, 0.0, 0.0, 24.0, 54.0, 330.0, 92.0)
	root.add_child(perk_row)

	round_label = _make_label("", 44, Color(0.85, 0.12, 0.12))
	round_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_place(round_label, 0.5, 0.0, 500.0, 60.0, 0.0, 34.0)
	root.add_child(round_label)

	remaining_label = _make_label("", 22, Color(0.9, 0.9, 0.9))
	remaining_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_place(remaining_label, 0.5, 0.0, 500.0, 30.0, 0.0, 92.0)
	root.add_child(remaining_label)

	status_label = _make_label("", 24, Color(0.5, 0.85, 1.0))
	status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_place(status_label, 0.5, 0.0, 600.0, 30.0, 0.0, 128.0)
	root.add_child(status_label)

	points_label = _make_label("", 28, Color(1.0, 0.85, 0.3))
	points_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_rect(points_label, 1.0, 0.0, 1.0, 0.0, -340.0, 16.0, -24.0, 54.0)
	root.add_child(points_label)

	weapon_label = _make_label("", 26, Color(0.9, 0.9, 0.9))
	weapon_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_rect(weapon_label, 1.0, 0.0, 1.0, 0.0, -340.0, 84.0, -24.0, 118.0)
	root.add_child(weapon_label)

	ammo_label = _make_label("", 40, Color.WHITE)
	ammo_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_rect(ammo_label, 1.0, 0.0, 1.0, 0.0, -340.0, 116.0, -24.0, 166.0)
	root.add_child(ammo_label)

	crosshair = Control.new()
	crosshair.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_place(crosshair, 0.5, 0.5, 60.0, 60.0)
	crosshair.draw.connect(_draw_crosshair)
	root.add_child(crosshair)

	hit_marker = Control.new()
	hit_marker.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_place(hit_marker, 0.5, 0.5, 60.0, 60.0)
	hit_marker.draw.connect(_draw_hit_marker)
	hit_marker.modulate = Color(1, 1, 1, 0)
	root.add_child(hit_marker)

	reload_bar = ProgressBar.new()
	reload_bar.show_percentage = false
	reload_bar.max_value = 100.0
	reload_bar.visible = false
	reload_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	reload_bar.add_theme_stylebox_override("background", _flat(Color(0.05, 0.05, 0.05, 0.6), Color(0, 0, 0, 0)))
	reload_bar.add_theme_stylebox_override("fill", _flat(Color(1.0, 0.85, 0.3, 0.95), Color(0, 0, 0, 0)))
	_place(reload_bar, 0.5, 0.62, 180.0, 10.0)
	root.add_child(reload_bar)

	message_label = _make_label("", 64, Color.WHITE)
	message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	message_label.modulate = Color(1, 1, 1, 0)
	_place(message_label, 0.5, 0.26, 1000.0, 80.0)
	root.add_child(message_label)

	prompt_label = _make_label("", 30, Color(1.0, 0.9, 0.5))
	prompt_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	prompt_label.visible = false
	_place(prompt_label, 0.5, 0.82, 760.0, 44.0)
	root.add_child(prompt_label)

	fire_right = _make_button(0.905, 0.55, 150.0, Color(0.9, 0.15, 0.15, 0.95), 30)
	fire_left = _make_button(0.095, 0.46, 120.0, Color(0.9, 0.15, 0.15, 0.95), 24)
	reload_button = _make_button(0.775, 0.8, 100.0, Color(1.0, 0.8, 0.2, 0.95), 18)
	switch_button = _make_button(0.905, 0.85, 100.0, Color(0.3, 0.6, 1.0, 0.95), 18)
	use_button = _make_button(0.74, 0.55, 120.0, Color(0.2, 0.9, 0.4, 0.95), 24)
	pause_button = _make_button(0.5, 0.115, 60.0, Color(0.8, 0.8, 0.8, 0.9), 22)
	pause_button.set("label_text", "II")
	_rect(pause_button, 0.5, 0.0, 0.5, 0.0, 250.0, 6.0, 310.0, 66.0)
	use_button.visible = false
	reload_button.connect("pressed", _on_reload_pressed)
	switch_button.connect("pressed", _on_switch_pressed)
	use_button.connect("pressed", _on_use_pressed)
	pause_button.connect("pressed", _on_pause_pressed)

	_build_game_over()


func _build_game_over() -> void:
	game_over_panel = ColorRect.new()
	game_over_panel.color = Color(0.0, 0.0, 0.0, 0.75)
	game_over_panel.visible = false
	game_over_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(game_over_panel)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	game_over_panel.add_child(center)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 16)
	center.add_child(box)

	var title := _make_label("", 72, Color(0.85, 0.1, 0.1))
	title.text = tr("OVER_TITLE")
	title.name = "Title"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(title)
	game_over_round = _make_label("", 32, Color.WHITE)
	game_over_round.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(game_over_round)
	game_over_points = _make_label("", 32, Color(1.0, 0.85, 0.3))
	game_over_points.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(game_over_points)

	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 30)
	box.add_child(row)
	row.add_child(_menu_button("RESTART", _on_restart_pressed))
	row.add_child(_menu_button("MAIN_MENU", _on_menu_pressed))


func _menu_button(key: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = tr(key)
	b.custom_minimum_size = Vector2(260.0, 70.0)
	b.add_theme_font_size_override("font_size", 28)
	b.pressed.connect(cb)
	return b


# ------------------------------------------------------------------ helpers

func _full_rect(color: Color) -> ColorRect:
	var r := ColorRect.new()
	r.color = color
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	r.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(r)
	return r


func _make_label(text: String, font_px: int, color: Color) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", font_px)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	l.add_theme_constant_override("outline_size", 6)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


func _make_button(ax: float, ay: float, diameter: float, ring: Color, font_px: int) -> Control:
	var b: Control = TouchButton.new()
	b.set("ring_color", ring)
	b.set("font_size", font_px)
	_place(b, ax, ay, diameter, diameter)
	root.add_child(b)
	return b


func _flat(bg: Color, border: Color) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(4)
	return sb


func _rect(c: Control, a_l: float, a_t: float, a_r: float, a_b: float, o_l: float, o_t: float, o_r: float, o_b: float) -> void:
	c.anchor_left = a_l
	c.anchor_top = a_t
	c.anchor_right = a_r
	c.anchor_bottom = a_b
	c.offset_left = o_l
	c.offset_top = o_t
	c.offset_right = o_r
	c.offset_bottom = o_b


func _place(c: Control, ax: float, ay: float, w: float, h: float, dx: float = 0.0, dy: float = 0.0) -> void:
	_rect(c, ax, ay, ax, ay, -w * 0.5 + dx, -h * 0.5 + dy, w * 0.5 + dx, h * 0.5 + dy)


func _draw_crosshair() -> void:
	var c := Vector2(30.0, 30.0)
	var col := Color(1, 1, 1, 0.85)
	crosshair.draw_line(c + Vector2(-14, 0), c + Vector2(-5, 0), col, 2.0)
	crosshair.draw_line(c + Vector2(14, 0), c + Vector2(5, 0), col, 2.0)
	crosshair.draw_line(c + Vector2(0, -14), c + Vector2(0, -5), col, 2.0)
	crosshair.draw_line(c + Vector2(0, 14), c + Vector2(0, 5), col, 2.0)
	crosshair.draw_circle(c, 1.5, col)


func _draw_hit_marker() -> void:
	var c := Vector2(30.0, 30.0)
	hit_marker.draw_line(c + Vector2(-10, -10), c + Vector2(-5, -5), Color.WHITE, 3.0)
	hit_marker.draw_line(c + Vector2(10, -10), c + Vector2(5, -5), Color.WHITE, 3.0)
	hit_marker.draw_line(c + Vector2(-10, 10), c + Vector2(-5, 5), Color.WHITE, 3.0)
	hit_marker.draw_line(c + Vector2(10, 10), c + Vector2(5, 5), Color.WHITE, 3.0)


# ------------------------------------------------------------------ signals

func _connect_signals() -> void:
	if combat != null:
		combat.connect("health_changed", _on_health_changed)
		combat.connect("damaged", _on_damaged)
		combat.connect("weapon_changed", _on_weapon_changed)
		combat.connect("ammo_changed", _on_ammo_changed)
		combat.connect("reload_started", _on_reload_started)
		combat.connect("reload_ended", _on_reload_ended)
		combat.connect("hit_confirmed", _on_hit_confirmed)
		combat.connect("perks_changed", _on_perks_changed)
		combat.connect("revived", _on_revived)
	if mode != null:
		mode.connect("round_started", _on_round_started)
		mode.connect("remaining_changed", _on_remaining_changed)
		mode.connect("points_changed", _on_points_changed)
		mode.connect("message", _on_message)
		mode.connect("game_over", _on_game_over)
		mode.connect("screen_flash", _on_screen_flash)
		mode.connect("status_changed", _on_status_changed)
	if interactor != null:
		interactor.connect("prompt_changed", _on_prompt_changed)


func _on_health_changed(current: float, maximum: float) -> void:
	health_bar.max_value = maximum
	health_bar.value = current
	health_label.text = str(int(ceil(current)))


func _on_damaged(_amount: float) -> void:
	hurt_flash.color = Color(0.8, 0.0, 0.0, 0.4)
	create_tween().tween_property(hurt_flash, "color:a", 0.0, 0.5)


func _on_weapon_changed(weapon_name: String, _index: int) -> void:
	weapon_label.text = weapon_name


func _on_ammo_changed(mag: int, reserve: int) -> void:
	ammo_label.text = "%d / %d" % [mag, reserve]
	ammo_label.add_theme_color_override("font_color", Color(1.0, 0.3, 0.3) if mag == 0 else Color.WHITE)


func _on_reload_started(duration: float) -> void:
	if _reload_tween != null:
		_reload_tween.kill()
	reload_bar.value = 0.0
	reload_bar.visible = true
	_reload_tween = create_tween()
	_reload_tween.tween_property(reload_bar, "value", 100.0, duration)


func _on_reload_ended() -> void:
	if _reload_tween != null:
		_reload_tween.kill()
	reload_bar.visible = false


func _on_hit_confirmed(killed: bool, headshot: bool) -> void:
	var c := Color.WHITE
	if killed:
		c = Color(1.0, 0.2, 0.2, 1.0)
	elif headshot:
		c = Color(1.0, 0.9, 0.2, 1.0)
	hit_marker.modulate = c
	create_tween().tween_property(hit_marker, "modulate:a", 0.0, 0.25)


func _on_perks_changed(perk_ids: Array) -> void:
	for c in perk_row.get_children():
		c.queue_free()
	for id in perk_ids:
		var info: Dictionary = DB.PERKS[String(id)]
		var box := ColorRect.new()
		box.color = info["color"]
		box.custom_minimum_size = Vector2(38.0, 38.0)
		box.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var l := _make_label(String(info["letter"]), 24, Color.BLACK)
		l.add_theme_constant_override("outline_size", 0)
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		l.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		box.add_child(l)
		perk_row.add_child(box)


func _on_revived() -> void:
	_on_message(tr("M_REVIVED"), 2.0)


func _on_round_started(n: int) -> void:
	_round = n
	_update_texts_light()


func _on_remaining_changed(r: int) -> void:
	_remaining = r
	_update_texts_light()


func _on_points_changed(p: int) -> void:
	_points = p
	_update_texts_light()


func _update_texts_light() -> void:
	round_label.text = (tr("HUD_ROUND") % _round) if _round > 0 else ""
	remaining_label.text = (tr("HUD_ZOMBIES") % _remaining) if _round > 0 else ""
	points_label.text = tr("HUD_POINTS") % _points


func _on_message(text: String, duration: float) -> void:
	if _msg_tween != null:
		_msg_tween.kill()
	message_label.text = text
	message_label.modulate = Color(1, 1, 1, 1)
	if duration > 0.0:
		_msg_tween = create_tween()
		_msg_tween.tween_interval(duration)
		_msg_tween.tween_property(message_label, "modulate:a", 0.0, 0.6)


func _on_screen_flash(color: Color, duration: float) -> void:
	screen_flash_rect.color = Color(color.r, color.g, color.b, 0.9)
	create_tween().tween_property(screen_flash_rect, "color:a", 0.0, duration)


func _on_status_changed(text: String) -> void:
	status_label.text = text


func _on_prompt_changed(text: String) -> void:
	if text == "":
		prompt_label.visible = false
		use_button.visible = false
	elif text.begins_with("!"):
		prompt_label.text = text.substr(1)
		prompt_label.visible = true
		use_button.visible = false
	else:
		prompt_label.text = text
		prompt_label.visible = true
		use_button.visible = true


func _on_game_over(round_reached: int, total_points: int) -> void:
	_go_round = round_reached
	_go_points = total_points
	game_over_round.text = tr("OVER_ROUND") % _go_round
	game_over_points.text = tr("OVER_POINTS") % _go_points
	game_over_panel.visible = true
	for b in [fire_right, fire_left, reload_button, switch_button, use_button, pause_button]:
		(b as Control).visible = false
	prompt_label.visible = false


func _on_reload_pressed() -> void:
	if combat != null:
		combat.call("start_reload")


func _on_switch_pressed() -> void:
	if combat != null:
		combat.call("next_weapon")


func _on_use_pressed() -> void:
	if interactor != null:
		interactor.call("use")


func _on_pause_pressed() -> void:
	if _pause_menu != null and is_instance_valid(_pause_menu):
		return
	_pause_menu = PauseMenu.new()
	get_parent().add_child(_pause_menu)
	_pause_menu.connect("closed", _on_pause_closed)


func _on_pause_closed() -> void:
	for b in [fire_right, fire_left, reload_button, switch_button, use_button, pause_button]:
		b.call("release")


func _on_restart_pressed() -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()


func _on_menu_pressed() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file("res://scenes/menu/MainMenu.tscn")
