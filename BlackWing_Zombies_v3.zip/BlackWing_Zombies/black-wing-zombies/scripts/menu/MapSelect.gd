extends Control


# =========================
# MAP DATA
# =========================

var maps: Array[Dictionary] = [
	{
		"name": "THE FACILITY",
		"description": "An abandoned facility where the outbreak began.\nSurvive the waves and uncover what happened here."
	},
	{
		"name": "THE DUNES",
		"description": "A forgotten desert site hiding something beneath the sand.\nSurvive the waves and explore the ruins."
	},
	{
		"name": "THE ASYLUM",
		"description": "An abandoned asylum surrounded by darkness.\nSurvive the waves and discover its secrets."
	}
]


var selected_map: int = 0


# =========================
# NODE REFERENCES
# =========================

@onready var map_01_button: Button = $Content/MainVBox/MapCard/CardHBox/MapList/Map01Button
@onready var map_02_button: Button = $Content/MainVBox/MapCard/CardHBox/MapList/Map02Button
@onready var map_03_button: Button = $Content/MainVBox/MapCard/CardHBox/MapList/Map03Button

@onready var previous_button: Button = $Content/MainVBox/MapCard/CardHBox/RightArea/NavigationRow/PreviousButton
@onready var start_button: Button = $Content/MainVBox/MapCard/CardHBox/RightArea/NavigationRow/StartButton
@onready var next_button: Button = $Content/MainVBox/MapCard/CardHBox/RightArea/NavigationRow/NextButton

@onready var map_name: Label = $Content/MainVBox/MapCard/CardHBox/RightArea/MapName
@onready var map_description: Label = $Content/MainVBox/MapCard/CardHBox/RightArea/MapDescription


# =========================
# READY
# =========================

func _ready() -> void:
	map_01_button.pressed.connect(_on_map_01_pressed)
	map_02_button.pressed.connect(_on_map_02_pressed)
	map_03_button.pressed.connect(_on_map_03_pressed)

	previous_button.pressed.connect(_on_previous_pressed)
	next_button.pressed.connect(_on_next_pressed)

	start_button.pressed.connect(_on_start_pressed)

	select_map(0)


# =========================
# SELECT MAP
# =========================

func select_map(index: int) -> void:
	if index < 0:
		index = maps.size() - 1

	if index >= maps.size():
		index = 0

	selected_map = index

	map_name.text = maps[selected_map]["name"]
	map_description.text = maps[selected_map]["description"]

	update_map_buttons()


# =========================
# UPDATE BUTTONS
# =========================

func update_map_buttons() -> void:
	map_01_button.modulate = Color(0.75, 0.75, 0.75)
	map_02_button.modulate = Color(0.75, 0.75, 0.75)
	map_03_button.modulate = Color(0.75, 0.75, 0.75)

	match selected_map:
		0:
			map_01_button.modulate = Color.WHITE

		1:
			map_02_button.modulate = Color.WHITE

		2:
			map_03_button.modulate = Color.WHITE


# =========================
# MAP BUTTONS
# =========================

func _on_map_01_pressed() -> void:
	select_map(0)


func _on_map_02_pressed() -> void:
	select_map(1)


func _on_map_03_pressed() -> void:
	select_map(2)


# =========================
# PREVIOUS
# =========================

func _on_previous_pressed() -> void:
	select_map(selected_map - 1)


# =========================
# NEXT
# =========================

func _on_next_pressed() -> void:
	select_map(selected_map + 1)


# =========================
# START MATCH
# =========================

func _on_start_pressed() -> void:
	print("Starting map: ", maps[selected_map]["name"])
	print("Selected Map ID: ", selected_map)

	var loading_screen: Control = load("res://scenes/game/LoadingScreen.tscn").instantiate()

	loading_screen.set_meta("selected_map", selected_map)

	get_tree().root.add_child(loading_screen)

	get_tree().current_scene.queue_free()

	get_tree().current_scene = loading_screen
