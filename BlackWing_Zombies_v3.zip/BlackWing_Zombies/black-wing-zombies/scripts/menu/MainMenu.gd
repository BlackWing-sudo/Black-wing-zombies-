extends Control

const SettingsPanel = preload("res://scripts/ui/SettingsPanel.gd")
const CreditsPanel = preload("res://scripts/ui/CreditsPanel.gd")

@onready var zombies_button: Button = $MenuCenter/MenuButtons/ZombiesButton
@onready var settings_button: Button = $MenuCenter/MenuButtons/SettingsButton
@onready var credits_button: Button = $MenuCenter/MenuButtons/CreditsButton
@onready var exit_button: Button = $MenuCenter/MenuButtons/ExitButton


func _ready() -> void:
	settings_button.pressed.connect(_on_settings_button_pressed)
	credits_button.pressed.connect(_on_credits_button_pressed)
	exit_button.pressed.connect(_on_exit_button_pressed)
	var s := get_node_or_null("/root/Settings")
	if s != null:
		s.connect("changed", _apply_texts)
	_apply_texts()


func _apply_texts() -> void:
	zombies_button.text = tr("MENU_ZOMBIES")
	settings_button.text = tr("MENU_SETTINGS")
	credits_button.text = tr("MENU_CREDITS")
	exit_button.text = tr("MENU_EXIT")


func _on_zombies_button_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/menu/MapSelect.tscn")


func _on_settings_button_pressed() -> void:
	add_child(SettingsPanel.new())


func _on_credits_button_pressed() -> void:
	add_child(CreditsPanel.new())


func _on_exit_button_pressed() -> void:
	get_tree().quit()
