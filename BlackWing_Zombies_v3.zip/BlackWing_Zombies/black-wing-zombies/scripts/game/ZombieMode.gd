extends Node
## ZombieMode - rounds, zones, spawning, points, power, teleport, game over.
## Scene needs: Player(+PlayerCombat), Zombies, SpawnPoints (Marker3D in group "zombie_spawn"
## with metadata "zone"), optional NavRegion (baked at runtime).

const Sfx = preload("res://scripts/game/Sfx.gd")
const DB = preload("res://scripts/game/GameDB.gd")
const ZombieScene: PackedScene = preload("res://scenes/zombie/Zombie.tscn")

signal round_started(round_number: int)
signal round_ended(round_number: int)
signal remaining_changed(remaining: int)
signal points_changed(points: int)
signal message(text: String, duration: float)
signal game_over(round_reached: int, total_points: int)
signal screen_flash(color: Color, duration: float)
signal status_changed(text: String)

enum State { PREPARING, INTERMISSION, ACTIVE, GAME_OVER }

@export var first_round_delay: float = 4.0
@export var between_rounds_delay: float = 7.0
@export var base_zombies: int = 6
@export var zombies_per_round: int = 4
@export var max_alive: int = 12
@export var min_spawn_distance: float = 9.0
@export var max_spawn_distance: float = 70.0
@export var points_per_hit: int = 10
@export var points_per_kill: int = 60
@export var points_per_headshot_kill: int = 100

var state: State = State.PREPARING
var round_number: int = 0
var points: int = DB.START_POINTS
var power_on: bool = false
var insta_kill: bool = false
var in_pap: bool = false

var player: CharacterBody3D
var combat: Node
var zombies_root: Node3D
var spawn_points: Array[Node3D] = []
var unlocked: Dictionary = {"start": true}
var nav_region: NavigationRegion3D
var nav_ready: bool = false

var _nav_done: bool = false
var _prepare_time: float = 0.0
var _announced: bool = false
var _intermission_left: float = 0.0
var _to_spawn: int = 0
var _alive: int = 0
var _spawn_timer: float = 0.0
var _paused_zombies: bool = false
var _teleporting: bool = false
var _stay_left: float = 0.0
var _return_to: Node3D = null
var _status_timer: float = 0.0
var _round_audio: AudioStreamPlayer


func _enter_tree() -> void:
	add_to_group("zombie_mode")


func _ready() -> void:
	player = get_node_or_null("../Player") as CharacterBody3D
	if player == null:
		push_error("ZombieMode: Player not found at ../Player")
		set_process(false)
		return
	combat = player.get_node_or_null("PlayerCombat")
	if combat != null:
		combat.connect("died", _on_player_died)
		combat.connect("hit_confirmed", _on_hit_confirmed)

	zombies_root = get_node_or_null("../Zombies") as Node3D
	if zombies_root == null:
		zombies_root = Node3D.new()
		zombies_root.name = "Zombies"
		add_child(zombies_root)

	for n in get_tree().get_nodes_in_group("zombie_spawn"):
		var sp := n as Node3D
		if sp != null:
			spawn_points.append(sp)

	_round_audio = AudioStreamPlayer.new()
	_round_audio.stream = Sfx.get_sound("round_start")
	_round_audio.volume_db = -4.0
	_round_audio.bus = "SFX"
	add_child(_round_audio)

	nav_region = get_node_or_null("../NavRegion") as NavigationRegion3D
	if nav_region != null and nav_region.navigation_mesh != null:
		nav_region.bake_finished.connect(_on_nav_baked)
		nav_region.bake_navigation_mesh(true)
	else:
		_nav_done = true


func _on_nav_baked() -> void:
	_nav_done = true
	var nm: NavigationMesh = nav_region.navigation_mesh
	nav_ready = nm != null and nm.get_polygon_count() > 0
	if not nav_ready:
		push_warning("ZombieMode: navmesh empty - zombies chase in a straight line.")


# ------------------------------------------------------------------ state machine

func _process(delta: float) -> void:
	_tick_status(delta)
	match state:
		State.PREPARING:
			if not _announced:
				_announced = true
				message.emit(tr("M_GET_READY"), first_round_delay)
				points_changed.emit(points)
			_prepare_time += delta
			var waited: bool = _prepare_time >= first_round_delay
			var nav_ok: bool = _nav_done or _prepare_time >= first_round_delay + 4.0
			if waited and nav_ok:
				_start_round(1)
		State.INTERMISSION:
			_intermission_left -= delta
			if _intermission_left <= 0.0:
				_start_round(round_number + 1)
		State.ACTIVE:
			_process_spawning(delta)
			if _to_spawn <= 0 and _alive <= 0:
				_end_round()
		State.GAME_OVER:
			pass


func _start_round(n: int) -> void:
	round_number = n
	_to_spawn = base_zombies + (n - 1) * zombies_per_round
	_spawn_timer = 1.5
	state = State.ACTIVE
	round_started.emit(n)
	remaining_changed.emit(_to_spawn + _alive)
	message.emit(tr("M_ROUND") % n, 3.0)
	if _round_audio.stream != null:
		_round_audio.play()


func _end_round() -> void:
	state = State.INTERMISSION
	_intermission_left = between_rounds_delay
	round_ended.emit(round_number)
	message.emit(tr("M_ROUND_DONE") % round_number, 3.5)


func _process_spawning(delta: float) -> void:
	if _to_spawn <= 0 or _paused_zombies:
		return
	_spawn_timer -= delta
	if _spawn_timer > 0.0 or _alive >= max_alive:
		return
	_spawn_zombie()
	_spawn_timer = maxf(0.45, 2.2 - round_number * 0.15)


func _tick_status(delta: float) -> void:
	if in_pap and not _teleporting:
		_stay_left -= delta
		if _stay_left <= 0.0:
			return_from_pap()
	_status_timer -= delta
	if _status_timer <= 0.0:
		_status_timer = 0.25
		var text: String = ""
		if in_pap:
			text = tr("S_RETURN") % int(ceil(maxf(_stay_left, 0.0)))
		status_changed.emit(text)


# ------------------------------------------------------------------ spawning

func _spawn_zombie() -> void:
	var z := ZombieScene.instantiate() as CharacterBody3D
	z.call("configure", player, _health_for_round(round_number), _speed_for_round(round_number), _damage_for_round(round_number), nav_ready)
	zombies_root.add_child(z)
	z.global_position = _pick_spawn_position()
	z.connect("died", _on_zombie_died)
	z.connect("stuck", _on_zombie_stuck)
	_to_spawn -= 1
	_alive += 1
	remaining_changed.emit(_to_spawn + _alive)


func _pick_spawn_position() -> Vector3:
	var ppos: Vector3 = player.global_position
	var open_points: Array[Node3D] = []
	var good: Array[Node3D] = []
	for sp in spawn_points:
		var zone: String = String(sp.get_meta("zone", "start"))
		if not unlocked.has(zone):
			continue
		open_points.append(sp)
		var d: float = sp.global_position.distance_to(ppos)
		if d >= min_spawn_distance and d <= max_spawn_distance:
			good.append(sp)
	if good.is_empty():
		good = open_points
	if good.is_empty():
		var a: float = randf() * TAU
		return ppos + Vector3(cos(a), 0.2, sin(a)) * randf_range(12.0, 16.0)
	var chosen: Node3D = good[randi() % good.size()]
	return chosen.global_position + Vector3(randf_range(-0.7, 0.7), 0.1, randf_range(-0.7, 0.7))


func _on_zombie_stuck(zombie: Node3D) -> void:
	if not is_instance_valid(zombie):
		return
	zombie.global_position = _pick_spawn_position()
	var body := zombie as CharacterBody3D
	if body != null:
		body.velocity = Vector3.ZERO
	if zombie.has_method("begin_rise"):
		zombie.call("begin_rise")


func _on_zombie_died(_zombie: Node3D, headshot: bool) -> void:
	_alive = maxi(0, _alive - 1)
	remaining_changed.emit(_to_spawn + _alive)
	add_points(points_per_headshot_kill if headshot else points_per_kill)


func _on_hit_confirmed(_killed: bool, _headshot: bool) -> void:
	add_points(points_per_hit)


func _on_player_died() -> void:
	state = State.GAME_OVER
	get_tree().call_group("zombie", "set_active", false)
	game_over.emit(round_number, points)


# ------------------------------------------------------------------ economy / world state

func add_points(amount: int) -> void:
	points += amount
	points_changed.emit(points)


func spend_points(amount: int) -> bool:
	if amount <= 0:
		return true
	if points < amount:
		message.emit(tr("M_NO_POINTS"), 1.2)
		return false
	points -= amount
	points_changed.emit(points)
	return true


func unlock_zones(zones: PackedStringArray) -> void:
	for z in zones:
		unlocked[String(z)] = true


func set_power(on: bool) -> void:
	power_on = on
	if on:
		message.emit(tr("M_POWER_ON"), 2.5)
		screen_flash.emit(Color(1.0, 0.95, 0.7, 1.0), 0.8)


# ------------------------------------------------------------------ teleport / Pack-a-Punch room

func teleport_to(dest: Node3D, back: Node3D, stay: float) -> void:
	if _teleporting or dest == null:
		return
	_teleporting = true
	message.emit(tr("M_TELEPORT"), 1.0)
	screen_flash.emit(Color(0.6, 0.85, 1.0, 1.0), 1.4)
	await get_tree().create_timer(0.7).timeout
	player.global_position = dest.global_position + Vector3(0.0, 0.1, 0.0)
	player.velocity = Vector3.ZERO
	_teleporting = false
	if stay > 0.0:
		in_pap = true
		_stay_left = stay
		_return_to = back
		_set_zombies_paused(true)
	else:
		in_pap = false
		_set_zombies_paused(false)


func return_from_pap() -> void:
	if not in_pap or _teleporting:
		return
	in_pap = false
	status_changed.emit("")
	teleport_to(_return_to, null, 0.0)


func _set_zombies_paused(p: bool) -> void:
	_paused_zombies = p
	get_tree().call_group("zombie", "set_active", not p)


# ------------------------------------------------------------------ difficulty curves

func _health_for_round(r: int) -> float:
	if r <= 9:
		return 100.0 + (r - 1) * 30.0
	return 340.0 * pow(1.1, r - 9)


func _speed_for_round(r: int) -> float:
	return clampf(1.5 + r * 0.25, 1.5, 3.4) * randf_range(0.9, 1.15)


func _damage_for_round(r: int) -> float:
	return minf(34.0, 18.0 + r * 1.5)
