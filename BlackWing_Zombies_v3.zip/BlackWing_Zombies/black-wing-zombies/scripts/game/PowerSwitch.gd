extends "res://scripts/game/Interactable.gd"
## Master power switch. Perk machines and the teleporter need it.

var _lever: Node3D


func _ready() -> void:
	radius = maxf(radius, 2.4)
	setup_base()
	solid_box(self, Vector3(1.0, 1.4, 0.35), Vector3(0.0, 1.0, 0.0), make_mat(Color(0.18, 0.2, 0.22)), true)
	solid_box(self, Vector3(0.7, 0.5, 0.05), Vector3(0.0, 1.35, 0.2), make_mat(Color(0.8, 0.15, 0.1), 0.6), false)
	_lever = Node3D.new()
	_lever.position = Vector3(0.0, 0.9, 0.2)
	_lever.rotation_degrees.x = 40.0
	add_child(_lever)
	solid_box(_lever, Vector3(0.08, 0.5, 0.08), Vector3(0.0, 0.25, 0.0), make_mat(Color(0.9, 0.9, 0.9)), false)


func get_prompt(game: Node, _combat: Node) -> String:
	if bool(game.get("power_on")):
		return ""
	return tr("P_POWER")


func interact(game: Node, _combat: Node) -> void:
	if bool(game.get("power_on")):
		return
	game.call("set_power", true)
	create_tween().tween_property(_lever, "rotation_degrees:x", -40.0, 0.4)
	play_sfx("power_on", 2.0)
