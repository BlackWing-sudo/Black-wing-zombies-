extends "res://scripts/game/Interactable.gd"
## Weapon drawn on a wall (chalk outline). Buy the weapon, or its ammo if you own it.
## Place the node ON the wall surface; yaw_deg: 0 faces +Z, 90 faces +X, 180 faces -Z, -90 faces -X.

const DB = preload("res://scripts/game/GameDB.gd")
const Models = preload("res://scripts/game/WeaponModels.gd")

@export var weapon_id: String = "SMG"


func _ready() -> void:
	radius = maxf(radius, 2.4)
	setup_base()
	var w: Dictionary = DB.WEAPONS[weapon_id]
	solid_box(self, Vector3(2.7, 1.5, 0.05), Vector3(0.0, 0.0, 0.03), make_mat(Color(0.5, 0.08, 0.08), 0.4), false)
	solid_box(self, Vector3(2.5, 1.3, 0.06), Vector3(0.0, 0.0, 0.05), make_mat(Color(0.07, 0.07, 0.08)), false)
	var chalk := Node3D.new()
	add_child(chalk)
	chalk.rotation_degrees.y = -90.0
	chalk.scale = Vector3(0.12, 1.5, 1.5)
	var zc: float = (float(w["muzzle_z"]) + 0.3) * 0.5
	chalk.position = Vector3(zc * 1.5, 0.0, 0.1)
	Models.fill(chalk, weapon_id, 2)
	var label := make_label("%s   %d" % [tr("W_" + weapon_id), int(w["price"])], 0.0045, Color(1.0, 0.9, 0.5), false)
	label.position = Vector3(0.0, -0.95, 0.1)
	add_child(label)


func get_prompt(_game: Node, combat: Node) -> String:
	var wname: String = tr("W_" + weapon_id)
	if bool(combat.call("has_weapon", weapon_id)):
		return tr("P_AMMO") % [wname, DB.ammo_price(weapon_id)]
	return tr("P_BUY") % [wname, int(DB.WEAPONS[weapon_id]["price"])]


func interact(game: Node, combat: Node) -> void:
	var owned: bool = bool(combat.call("has_weapon", weapon_id))
	var price: int = DB.ammo_price(weapon_id) if owned else int(DB.WEAPONS[weapon_id]["price"])
	if not bool(game.call("spend_points", price)):
		return
	if owned:
		combat.call("buy_ammo", weapon_id)
	else:
		combat.call("give_weapon", weapon_id)
	play_sfx("buy", 0.0)
