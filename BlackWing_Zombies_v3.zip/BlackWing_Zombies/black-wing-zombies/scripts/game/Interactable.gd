extends Node3D
## Base class for everything the player can USE (doors, wall buys, perks, box...).
## get_prompt(): "" = nothing, "!text" = info only (no USE button), else = actionable text.

const Sfx = preload("res://scripts/game/Sfx.gd")

@export var radius: float = 2.4
@export var yaw_deg: float = 0.0


func setup_base() -> void:
	rotation_degrees.y = yaw_deg
	add_to_group("interactable")


func get_prompt(_game: Node, _combat: Node) -> String:
	return ""


func interact(_game: Node, _combat: Node) -> void:
	pass


func play_sfx(sound_name: String, volume_db: float = 0.0) -> void:
	var stream: AudioStream = Sfx.get_sound(sound_name)
	if stream == null:
		return
	var p := AudioStreamPlayer3D.new()
	p.stream = stream
	p.volume_db = volume_db
	p.max_distance = 40.0
	p.unit_size = 8.0
	p.bus = "SFX"
	add_child(p)
	p.play()
	p.finished.connect(p.queue_free)


func make_mat(color: Color, emission: float = 0.0, unshaded: bool = false) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.85
	if emission > 0.0:
		m.emission_enabled = true
		m.emission = color
		m.emission_energy_multiplier = emission
	if unshaded:
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	return m


func solid_box(parent: Node3D, box_size: Vector3, pos: Vector3, mat: Material, collide: bool) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = box_size
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	if collide:
		var body := StaticBody3D.new()
		body.position = pos
		var cs := CollisionShape3D.new()
		var sh := BoxShape3D.new()
		sh.size = box_size
		cs.shape = sh
		body.add_child(cs)
		parent.add_child(body)
	return mi


func make_label(text: String, pixel: float, color: Color, billboard: bool) -> Label3D:
	var l := Label3D.new()
	l.text = text
	l.font_size = 64
	l.pixel_size = pixel
	l.modulate = color
	l.outline_size = 14
	if billboard:
		l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	return l


func game_node() -> Node:
	return get_tree().get_first_node_in_group("zombie_mode")
