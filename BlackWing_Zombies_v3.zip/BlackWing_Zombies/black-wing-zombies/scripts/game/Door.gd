extends Node3D

@onready var interaction_area: Area3D = $InteractionArea
@onready var door_pivot: Node3D = $DoorPivot
@onready var game_ui: CanvasLayer = get_node("../../GameUI")
@onready var open_button: Button = game_ui.get_node("HUD/OpenButton")

var player_inside: bool = false
var is_open: bool = false

const CLOSED_ROTATION: float = 0.0
const OPEN_ROTATION: float = -90.0

func _ready() -> void:
	open_button.visible = false

	interaction_area.body_entered.connect(_on_body_entered)
	interaction_area.body_exited.connect(_on_body_exited)

	open_button.pressed.connect(_on_open_button_pressed)


func _on_body_entered(body: Node3D) -> void:
	if body.name == "Player":
		player_inside = true
		open_button.visible = true


func _on_body_exited(body: Node3D) -> void:
	if body.name == "Player":
		player_inside = false
		open_button.visible = false


func _on_open_button_pressed() -> void:
	if not player_inside:
		return

	if is_open:
		close_door()
	else:
		open_door()


func open_door() -> void:
	is_open = true
	open_button.text = "CLOSE"

	var tween := create_tween()

	tween.tween_property(
		door_pivot,
		"rotation_degrees:y",
		OPEN_ROTATION,
		0.6
	).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)


func close_door() -> void:
	is_open = false
	open_button.text = "OPEN"

	var tween := create_tween()

	tween.tween_property(
		door_pivot,
		"rotation_degrees:y",
		CLOSED_ROTATION,
		0.6
	).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
