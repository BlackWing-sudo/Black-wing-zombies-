extends "res://scripts/game/Interactable.gd"
## Pack-a-Punch machine (in the teleport room): upgrades the weapon in your hands.

const DB = preload("res://scripts/game/GameDB.gd")


func _ready() -> void:
	radius = maxf(radius, 2.8)
	setup_base()
	var purple := Color(0.6, 0.2, 1.0)
	solid_box(self, Vector3(1.8, 2.6, 1.2), Vector3(0.0, 1.3, 0.0), make_mat(Color(0.1, 0.06, 0.16)), true)
	solid_box(self, Vector3(1.3, 1.2, 0.06), Vector3(0.0, 1.5, 0.63), make_mat(purple, 1.6), false)
	solid_box(self, Vector3(1.8, 0.5, 1.25), Vector3(0.0, 2.85, 0.0), make_mat(purple, 1.2), false)
	var label := make_label("PACK-A-PUNCH", 0.0055, purple.lightened(0.4), true)
	label.position = Vector3(0.0, 3.6, 0.0)
	add_child(label)


func get_prompt(_game: Node, combat: Node) -> String:
	if bool(combat.call("current_is_pap")):
		return "!" + tr("P_PAP_DONE")
	return tr("P_PAP") % [tr("W_" + String(combat.call("current_id"))), DB.PAP_COST]


func interact(game: Node, combat: Node) -> void:
	if bool(combat.call("current_is_pap")):
		return
	if not bool(game.call("spend_points", DB.PAP_COST)):
		return
	combat.call("upgrade_current")
	game.emit_signal("message", tr("M_UPGRADED"), 2.0)
	game.emit_signal("screen_flash", Color(0.6, 0.2, 1.0, 1.0), 0.6)
	play_sfx("perk", 2.0)
