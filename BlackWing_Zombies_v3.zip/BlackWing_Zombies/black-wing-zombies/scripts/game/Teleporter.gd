extends "res://scripts/game/Interactable.gd"
## kind "pad": pay, teleport to the Pack-a-Punch room (auto-return after stay_time).
## kind "return": free pad inside the Pack-a-Punch room.

const DB = preload("res://scripts/game/GameDB.gd")

@export var kind: String = "pad"
@export var cost: int = 1500
@export var destination_name: String = "PapArrival"
@export var back_name: String = "PadReturn"
@export var stay_time: float = 30.0

var _mat: StandardMaterial3D
var _time: float = 0.0


func _ready() -> void:
	radius = maxf(radius, 2.2)
	setup_base()
	var base := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 1.5
	cm.bottom_radius = 1.5
	cm.height = 0.12
	base.mesh = cm
	_mat = make_mat(Color(0.2, 0.6, 1.0), 0.0)
	base.material_override = _mat
	base.position = Vector3(0.0, 0.06, 0.0)
	add_child(base)
	var label := make_label("TELEPORTER" if kind == "pad" else "EXIT", 0.005, Color(0.5, 0.85, 1.0), true)
	label.position = Vector3(0.0, 2.2, 0.0)
	add_child(label)


func _process(delta: float) -> void:
	_time += delta
	var g: Node = game_node()
	var on: bool = kind == "return" or (g != null and bool(g.get("power_on")))
	_mat.emission_enabled = on
	_mat.emission = Color(0.2, 0.6, 1.0)
	_mat.emission_energy_multiplier = 1.2 + sin(_time * 3.0) * 0.6


func get_prompt(game: Node, _combat: Node) -> String:
	if kind == "return":
		return tr("P_RETURN")
	if not bool(game.get("power_on")):
		return "!" + tr("P_NEED_POWER")
	return tr("P_TELEPORT") % cost


func interact(game: Node, _combat: Node) -> void:
	if kind == "return":
		game.call("return_from_pap")
		return
	var dest := get_tree().current_scene.find_child(destination_name, true, false) as Node3D
	var back := get_tree().current_scene.find_child(back_name, true, false) as Node3D
	if dest == null:
		return
	if not bool(game.call("spend_points", cost)):
		return
	play_sfx("teleport", 0.0)
	game.call("teleport_to", dest, back, stay_time)
