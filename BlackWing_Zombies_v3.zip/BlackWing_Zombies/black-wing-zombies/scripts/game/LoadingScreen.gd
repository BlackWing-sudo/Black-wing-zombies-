extends Control


@onready var map_name: Label = $Content/MainVBox/MapName
@onready var map_description: Label = $Content/MainVBox/MapDescription
@onready var loading_bar: ProgressBar = $Content/MainVBox/LoadingBar
@onready var loading_percent: Label = $Content/MainVBox/LoadingPercent
@onready var loading_label: Label = $Content/MainVBox/LoadingLabel


var selected_map: int = 0
var loading_value: float = 0.0
var loading_speed: float = 35.0


var maps: Array[Dictionary] = [
	{
		"name": "THE FACILITY",
		"description": "An abandoned facility where the outbreak began.\nSurvive the waves and uncover what happened here."
	},
	{
		"name": "THE DUNES",
		"description": "A forgotten desert site hiding something beneath the sand.\nSurvive the waves and explore the ruins."
	},
	{
		"name": "THE ASYLUM",
		"description": "An abandoned asylum surrounded by darkness.\nSurvive the waves and discover its secrets."
	}
]


# Scene loaded for each map (Dunes / Asylum are placeholders for now).
var map_scenes: Array[String] = [
	"res://scenes/maps/ZombieMap.tscn",
	"res://scenes/maps/ZombieMap.tscn",
	"res://scenes/maps/ZombieMap.tscn"
]

func _ready() -> void:
	# Read selected map from the previous scene.
	selected_map = get_meta("selected_map", 0)

	if selected_map < 0 or selected_map >= maps.size():
		selected_map = 0

	map_name.text = maps[selected_map]["name"]
	map_description.text = maps[selected_map]["description"]

	loading_bar.value = 0
	loading_percent.text = "0%"
	loading_label.text = "LOADING..."


func _process(delta: float) -> void:
	if loading_value >= 100.0:
		return

	loading_value += loading_speed * delta

	if loading_value >= 100.0:
		loading_value = 100.0

	loading_bar.value = loading_value
	loading_percent.text = str(int(loading_value)) + "%"

	if loading_value >= 100.0:
		loading_label.text = "READY"

		await get_tree().create_timer(0.8).timeout

		print("Loading finished: ", maps[selected_map]["name"])

		get_tree().change_scene_to_file(map_scenes[selected_map])
