extends RefCounted
## Tiny helper: loads optional sound files from res://assets/audio/
## If a sound file is missing the game simply stays silent (no crash).
##
## Usage:  const Sfx = preload("res://scripts/game/Sfx.gd")
##         var s: AudioStream = Sfx.get_sound("shot_pistol")

static var _cache: Dictionary = {}


static func get_sound(sound_name: String) -> AudioStream:
	if _cache.has(sound_name):
		return _cache[sound_name] as AudioStream

	var path: String = "res://assets/audio/%s.wav" % sound_name
	var stream: AudioStream = null
	if ResourceLoader.exists(path):
		stream = load(path) as AudioStream

	_cache[sound_name] = stream
	return stream
