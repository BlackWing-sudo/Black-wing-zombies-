extends Node
## Finds the nearest Interactable around the player and runs it when the USE button is pressed.

signal prompt_changed(text: String)

var player: CharacterBody3D
var combat: Node
var mode: Node
var current: Node3D = null
var _prompt: String = ""
var _timer: float = 0.0


func _ready() -> void:
	player = get_node_or_null("../Player") as CharacterBody3D
	if player != null:
		combat = player.get_node_or_null("PlayerCombat")
	mode = get_node_or_null("../ZombieMode")


func _process(delta: float) -> void:
	if player == null or combat == null:
		return
	_timer -= delta
	if _timer > 0.0:
		return
	_timer = 0.1

	var best: Node3D = null
	var best_d: float = 1000000.0
	var best_prompt: String = ""
	if not bool(combat.get("dead")):
		for n in get_tree().get_nodes_in_group("interactable"):
			var it := n as Node3D
			if it == null:
				continue
			var dv: Vector3 = it.global_position - player.global_position
			var d: float = Vector2(dv.x, dv.z).length()   # horizontal distance only
			if d > float(it.get("radius")) or d >= best_d:
				continue
			var text: String = String(it.call("get_prompt", mode, combat))
			if text == "":
				continue
			best = it
			best_d = d
			best_prompt = text
	current = best
	if best_prompt != _prompt:
		_prompt = best_prompt
		prompt_changed.emit(_prompt)


func use() -> void:
	if current == null or not is_instance_valid(current) or _prompt == "" or _prompt.begins_with("!"):
		return
	current.call("interact", mode, combat)
	_timer = 0.0
