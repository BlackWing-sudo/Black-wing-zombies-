extends "res://scripts/game/Interactable.gd"
## Sliding double door opened with points. Opens the zones listed in opens_zones.
## yaw_deg = 0 for a wall running along X, 90 for a wall running along Z.
## NOTE: keep doors OUTSIDE the NavRegion so the navmesh has an opening here.

@export var cost: int = 750
@export var width: float = 3.4
@export var height: float = 4.5
@export var opens_zones: PackedStringArray = PackedStringArray()

var opened: bool = false
var _leaf_l: Node3D
var _leaf_r: Node3D
var _shapes: Array[CollisionShape3D] = []
var _label: Label3D


func _ready() -> void:
	radius = maxf(radius, 3.6)
	setup_base()
	var steel := make_mat(Color(0.2, 0.22, 0.25))
	var stripe := make_mat(Color(0.9, 0.7, 0.05), 0.3)
	_leaf_l = _make_leaf(-1.0, steel, stripe)
	_leaf_r = _make_leaf(1.0, steel, stripe)
	_label = make_label(str(cost), 0.007, Color(1.0, 0.85, 0.2), true)
	_label.position = Vector3(0.0, 2.6, 0.0)
	add_child(_label)


func _make_leaf(side: float, steel: Material, stripe: Material) -> Node3D:
	var leaf := Node3D.new()
	leaf.position = Vector3(side * width * 0.25, 0.0, 0.0)
	add_child(leaf)
	var half: float = width * 0.5
	solid_box(leaf, Vector3(half, height, 0.3), Vector3(0.0, height * 0.5, 0.0), steel, false)
	solid_box(leaf, Vector3(half * 0.9, 0.25, 0.34), Vector3(0.0, height * 0.35, 0.0), stripe, false)
	solid_box(leaf, Vector3(half * 0.9, 0.25, 0.34), Vector3(0.0, height * 0.65, 0.0), stripe, false)
	var body := StaticBody3D.new()
	body.position = Vector3(0.0, height * 0.5, 0.0)
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = Vector3(half, height, 0.3)
	cs.shape = sh
	body.add_child(cs)
	leaf.add_child(body)
	_shapes.append(cs)
	return leaf


func get_prompt(_game: Node, _combat: Node) -> String:
	if opened:
		return ""
	return tr("P_DOOR") % cost


func interact(game: Node, _combat: Node) -> void:
	if opened:
		return
	if not bool(game.call("spend_points", cost)):
		return
	opened = true
	remove_from_group("interactable")
	game.call("unlock_zones", opens_zones)
	game.emit_signal("message", tr("M_DOOR_OPEN"), 1.5)
	play_sfx("door_open", 2.0)
	_label.visible = false
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(_leaf_l, "position:x", -width * 0.75, 1.3).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.tween_property(_leaf_r, "position:x", width * 0.75, 1.3).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	get_tree().create_timer(1.0).timeout.connect(_disable_collision)


func _disable_collision() -> void:
	for cs in _shapes:
		cs.disabled = true
