extends "res://scripts/game/Interactable.gd"
## Perk vending machine. Needs the power to be ON. Perk data lives in GameDB.PERKS.

const DB = preload("res://scripts/game/GameDB.gd")

@export var perk_id: String = "JUGGERNOG"

var _col: Color = Color.WHITE
var _panel_mat: StandardMaterial3D
var _sign_mat: StandardMaterial3D
var _lit: bool = false


func _ready() -> void:
	radius = maxf(radius, 2.6)
	setup_base()
	var info: Dictionary = DB.PERKS[perk_id]
	_col = info["color"]
	solid_box(self, Vector3(1.4, 2.3, 1.0), Vector3(0.0, 1.15, 0.0), make_mat(Color(0.12, 0.12, 0.14)), true)
	_panel_mat = make_mat(_col.darkened(0.7))
	solid_box(self, Vector3(1.0, 1.1, 0.06), Vector3(0.0, 1.3, 0.53), _panel_mat, false)
	_sign_mat = make_mat(_col.darkened(0.7))
	solid_box(self, Vector3(1.4, 0.45, 1.05), Vector3(0.0, 2.5, 0.0), _sign_mat, false)
	var label := make_label(tr("PERK_" + perk_id), 0.0045, _col, true)
	label.position = Vector3(0.0, 3.15, 0.0)
	add_child(label)


func _process(_delta: float) -> void:
	var g: Node = game_node()
	var on: bool = g != null and bool(g.get("power_on"))
	if on == _lit:
		return
	_lit = on
	for m in [_panel_mat, _sign_mat]:
		var mat := m as StandardMaterial3D
		mat.albedo_color = _col if on else _col.darkened(0.7)
		mat.emission_enabled = on
		mat.emission = _col
		mat.emission_energy_multiplier = 1.6


func get_prompt(game: Node, combat: Node) -> String:
	if not bool(game.get("power_on")):
		return "!" + tr("P_NEED_POWER")
	if bool(combat.call("has_perk", perk_id)):
		return "!" + tr("P_OWNED") % tr("PERK_" + perk_id)
	return tr("P_PERK") % [tr("PERK_" + perk_id), int(DB.PERKS[perk_id]["cost"])]


func interact(game: Node, combat: Node) -> void:
	if not bool(game.get("power_on")) or bool(combat.call("has_perk", perk_id)):
		return
	if not bool(game.call("spend_points", int(DB.PERKS[perk_id]["cost"]))):
		return
	combat.call("add_perk", perk_id)
	game.emit_signal("message", tr("M_PERK_GOT") % tr("PERK_" + perk_id), 2.0)
	play_sfx("perk", 0.0)
