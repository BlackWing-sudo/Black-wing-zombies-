extends RefCounted
## Shared game data: weapons, perks, prices.
## Edit numbers here to rebalance the whole game.

const START_POINTS: int = 500
const BOX_COST: int = 950
const PAP_COST: int = 5000
const PAP_DAMAGE: float = 2.5
const PAP_MAG: float = 1.5
const PAP_RESERVE: float = 1.5

const WEAPON_ORDER: Array = ["PISTOL", "SMG", "RIFLE", "SHOTGUN", "SNIPER"]

# price = wall-buy price (ammo refill costs half). 0 = not sold on walls.
const WEAPONS: Dictionary = {
	"PISTOL": {"name": "PISTOL", "pap_name": "MUSTANG & SALLY", "price": 0, "damage": 28.0, "interval": 0.2, "auto": false, "mag": 12, "reserve": 96, "reload": 1.1, "pellets": 1, "spread": 0.4, "range": 80.0, "head": 2.0, "kick": 0.05, "sound": "shot_pistol", "muzzle_z": -0.3},
	"SMG": {"name": "SMG", "pap_name": "SPITFIRE", "price": 1000, "damage": 15.0, "interval": 0.075, "auto": true, "mag": 32, "reserve": 224, "reload": 1.6, "pellets": 1, "spread": 2.0, "range": 60.0, "head": 1.8, "kick": 0.025, "sound": "shot_smg", "muzzle_z": -0.5},
	"RIFLE": {"name": "RIFLE", "pap_name": "RAPTOR", "price": 1200, "damage": 24.0, "interval": 0.11, "auto": true, "mag": 30, "reserve": 180, "reload": 2.0, "pellets": 1, "spread": 1.0, "range": 100.0, "head": 2.0, "kick": 0.04, "sound": "shot_rifle", "muzzle_z": -0.8},
	"SHOTGUN": {"name": "SHOTGUN", "pap_name": "HELLFIRE", "price": 1500, "damage": 14.0, "interval": 0.85, "auto": false, "mag": 6, "reserve": 36, "reload": 2.4, "pellets": 8, "spread": 5.0, "range": 30.0, "head": 1.5, "kick": 0.14, "sound": "shot_shotgun", "muzzle_z": -0.78},
	"SNIPER": {"name": "SNIPER", "pap_name": "RAILGUN", "price": 1750, "damage": 130.0, "interval": 1.2, "auto": false, "mag": 5, "reserve": 30, "reload": 2.6, "pellets": 1, "spread": 0.0, "range": 200.0, "head": 3.0, "kick": 0.2, "sound": "shot_sniper", "muzzle_z": -0.98},
}

const PERK_ORDER: Array = ["JUGGERNOG", "SPEED_COLA", "DOUBLE_TAP", "QUICK_REVIVE", "STAMIN_UP", "DEADSHOT", "MULE_KICK"]

const PERKS: Dictionary = {
	"JUGGERNOG": {"name": "JUGGER-NOG", "letter": "J", "color": Color(0.85, 0.12, 0.12), "cost": 2500, "desc": "Max health x2.5"},
	"SPEED_COLA": {"name": "SPEED COLA", "letter": "S", "color": Color(0.2, 0.8, 0.3), "cost": 3000, "desc": "Reload twice as fast"},
	"DOUBLE_TAP": {"name": "DOUBLE TAP", "letter": "D", "color": Color(0.95, 0.8, 0.1), "cost": 2000, "desc": "Faster fire rate"},
	"QUICK_REVIVE": {"name": "QUICK REVIVE", "letter": "Q", "color": Color(0.2, 0.6, 1.0), "cost": 1500, "desc": "Revive once when downed"},
	"STAMIN_UP": {"name": "STAMIN-UP", "letter": "U", "color": Color(1.0, 0.55, 0.1), "cost": 2000, "desc": "Run faster"},
	"DEADSHOT": {"name": "DEADSHOT", "letter": "H", "color": Color(0.75, 0.75, 0.82), "cost": 1500, "desc": "Tight aim + headshot damage"},
	"MULE_KICK": {"name": "MULE KICK", "letter": "M", "color": Color(0.1, 0.75, 0.65), "cost": 4000, "desc": "Carry a 3rd weapon"},
}


static func ammo_price(weapon_id: String) -> int:
	return maxi(250, int(WEAPONS[weapon_id]["price"]) / 2)
