extends "res://scripts/game/Interactable.gd"
## Mystery Box: pay, watch the weapons spin, take the result (random from the real weapon list).

const DB = preload("res://scripts/game/GameDB.gd")
const Models = preload("res://scripts/game/WeaponModels.gd")

enum State { IDLE, SPINNING, READY }

var state: State = State.IDLE
var _display: Node3D
var _lid: Node3D
var _spin_left: float = 0.0
var _swap_left: float = 0.0
var _ready_left: float = 0.0
var _result: String = ""
var _time: float = 0.0


func _ready() -> void:
	radius = maxf(radius, 2.6)
	setup_base()
	solid_box(self, Vector3(1.6, 0.8, 0.8), Vector3(0.0, 0.4, 0.0), make_mat(Color(0.3, 0.2, 0.1)), true)
	solid_box(self, Vector3(1.66, 0.12, 0.86), Vector3(0.0, 0.1, 0.0), make_mat(Color(0.15, 0.15, 0.15)), false)
	_lid = Node3D.new()
	_lid.position = Vector3(0.0, 0.8, -0.4)
	add_child(_lid)
	solid_box(_lid, Vector3(1.66, 0.12, 0.86), Vector3(0.0, 0.06, 0.4), make_mat(Color(0.36, 0.24, 0.12)), false)
	var q := make_label("?", 0.008, Color(1.0, 0.85, 0.2), true)
	q.position = Vector3(0.0, 1.4, 0.0)
	add_child(q)
	var beam_mat := make_mat(Color(0.3, 0.8, 1.0, 0.25), 1.0, true)
	beam_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	solid_box(self, Vector3(0.25, 7.0, 0.25), Vector3(0.0, 3.5, 0.0), beam_mat, false)
	_display = Node3D.new()
	_display.position = Vector3(0.0, 1.7, 0.0)
	_display.scale = Vector3.ONE * 1.3
	add_child(_display)


func get_prompt(_game: Node, _combat: Node) -> String:
	match state:
		State.IDLE:
			return tr("P_BOX") % DB.BOX_COST
		State.READY:
			return tr("P_TAKE") % tr("W_" + _result)
	return ""


func interact(game: Node, combat: Node) -> void:
	if state == State.IDLE:
		if not bool(game.call("spend_points", DB.BOX_COST)):
			return
		state = State.SPINNING
		_spin_left = 3.5
		_swap_left = 0.0
		create_tween().tween_property(_lid, "rotation_degrees:x", -70.0, 0.3)
		play_sfx("buy", 0.0)
	elif state == State.READY:
		combat.call("give_weapon", _result)
		_reset()


func _process(delta: float) -> void:
	_time += delta
	if state == State.IDLE:
		return
	_display.position.y = 1.7 + sin(_time * 3.0) * 0.08
	_display.rotation.y += delta * 1.5
	if state == State.SPINNING:
		_spin_left -= delta
		_swap_left -= delta
		if _swap_left <= 0.0:
			_swap_left = 0.15
			_show(DB.WEAPON_ORDER[randi() % DB.WEAPON_ORDER.size()])
		if _spin_left <= 0.0:
			_result = _pick_result()
			_show(_result)
			state = State.READY
			_ready_left = 8.0
			play_sfx("perk", 0.0)
	elif state == State.READY:
		_ready_left -= delta
		if _ready_left <= 0.0:
			_reset()


func _pick_result() -> String:
	var combat: Node = get_tree().get_first_node_in_group("player").get_node_or_null("PlayerCombat")
	var pool: Array[String] = []
	for id in DB.WEAPON_ORDER:
		if String(id) == "PISTOL":
			continue
		if combat != null and String(combat.call("current_id")) == String(id):
			continue
		pool.append(String(id))
	if pool.is_empty():
		return "SMG"
	return pool[randi() % pool.size()]


func _show(id: String) -> void:
	for c in _display.get_children():
		c.queue_free()
	Models.fill(_display, id, 0)


func _reset() -> void:
	state = State.IDLE
	for c in _display.get_children():
		c.queue_free()
	create_tween().tween_property(_lid, "rotation_degrees:x", 0.0, 0.3)
