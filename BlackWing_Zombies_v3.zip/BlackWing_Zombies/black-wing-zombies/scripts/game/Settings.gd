extends Node
## Autoload "Settings": saved options (volume, sensitivity, language) + all translations.
## Add new texts to _EN / _AR below and use tr("KEY") anywhere in the game.

signal changed

const SAVE_PATH: String = "user://settings.cfg"
const SFX_BUS: String = "SFX"

var master_volume: float = 1.0
var sfx_volume: float = 1.0
var look_sensitivity: float = 1.0
var language: String = "en"


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_ensure_sfx_bus()
	_build_translations()
	load_settings()
	apply()


func load_settings() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) != OK:
		return
	master_volume = float(cfg.get_value("audio", "master", 1.0))
	sfx_volume = float(cfg.get_value("audio", "sfx", 1.0))
	look_sensitivity = float(cfg.get_value("controls", "sensitivity", 1.0))
	language = String(cfg.get_value("general", "language", "en"))


func save_settings() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("audio", "master", master_volume)
	cfg.set_value("audio", "sfx", sfx_volume)
	cfg.set_value("controls", "sensitivity", look_sensitivity)
	cfg.set_value("general", "language", language)
	cfg.save(SAVE_PATH)


func apply() -> void:
	TranslationServer.set_locale(language)
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(master_volume, 0.0001)))
	var sfx_idx: int = AudioServer.get_bus_index(SFX_BUS)
	if sfx_idx >= 0:
		AudioServer.set_bus_volume_db(sfx_idx, linear_to_db(maxf(sfx_volume, 0.0001)))
	changed.emit()


func set_language(code: String) -> void:
	language = code
	apply()
	save_settings()


func set_master(v: float) -> void:
	master_volume = v
	apply()
	save_settings()


func set_sfx(v: float) -> void:
	sfx_volume = v
	apply()
	save_settings()


func set_sensitivity(v: float) -> void:
	look_sensitivity = v
	save_settings()
	changed.emit()


func _ensure_sfx_bus() -> void:
	if AudioServer.get_bus_index(SFX_BUS) >= 0:
		return
	AudioServer.add_bus()
	var idx: int = AudioServer.bus_count - 1
	AudioServer.set_bus_name(idx, SFX_BUS)
	AudioServer.set_bus_send(idx, "Master")


func _build_translations() -> void:
	for pair in [["en", _EN], ["ar", _AR]]:
		var t := Translation.new()
		t.locale = String(pair[0])
		var d: Dictionary = pair[1]
		for k in d:
			t.add_message(StringName(k), String(d[k]))
		TranslationServer.add_translation(t)


const _EN: Dictionary = {
	"MENU_ZOMBIES": "ZOMBIES", "MENU_SETTINGS": "SETTINGS", "MENU_CREDITS": "CREDITS", "MENU_EXIT": "EXIT",
	"HUD_ROUND": "ROUND %d", "HUD_ZOMBIES": "ZOMBIES  %d", "HUD_POINTS": "POINTS  %d",
	"HUD_FIRE": "FIRE", "HUD_RELOAD": "RELOAD", "HUD_SWITCH": "SWITCH", "HUD_USE": "USE",
	"W_PISTOL": "PISTOL", "W_SMG": "SMG", "W_RIFLE": "RIFLE", "W_SHOTGUN": "SHOTGUN", "W_SNIPER": "SNIPER",
	"P_DOOR": "OPEN DOOR  [%d]", "P_BUY": "BUY  %s  [%d]", "P_AMMO": "BUY AMMO  %s  [%d]",
	"P_PERK": "%s  [%d]", "P_BOX": "MYSTERY BOX  [%d]", "P_TAKE": "TAKE  %s",
	"P_POWER": "TURN ON POWER", "P_NEED_POWER": "POWER REQUIRED", "P_TELEPORT": "TELEPORT  [%d]",
	"P_RETURN": "RETURN", "P_PAP": "PACK-A-PUNCH  %s  [%d]", "P_PAP_DONE": "WEAPON ALREADY UPGRADED",
	"P_OWNED": "%s OWNED",
	"M_GET_READY": "GET READY", "M_ROUND": "ROUND %d", "M_ROUND_DONE": "ROUND %d SURVIVED",
	"M_NO_POINTS": "NOT ENOUGH POINTS", "M_POWER_ON": "POWER IS ON", "M_PERK_GOT": "%s ACQUIRED",
	"M_REVIVED": "REVIVED", "M_UPGRADED": "WEAPON UPGRADED", "M_TELEPORT": "TELEPORTING",
	"M_DOOR_OPEN": "DOOR OPENED", "S_RETURN": "RETURNING IN %d",
	"PERK_JUGGERNOG": "JUGGER-NOG", "PERK_SPEED_COLA": "SPEED COLA", "PERK_DOUBLE_TAP": "DOUBLE TAP",
	"PERK_QUICK_REVIVE": "QUICK REVIVE", "PERK_STAMIN_UP": "STAMIN-UP", "PERK_DEADSHOT": "DEADSHOT", "PERK_MULE_KICK": "MULE KICK",
	"PAUSE": "PAUSED", "RESUME": "RESUME", "RESTART": "RESTART", "SETTINGS": "SETTINGS", "MAIN_MENU": "MAIN MENU",
	"OVER_TITLE": "YOU DIED", "OVER_ROUND": "ROUND REACHED: %d", "OVER_POINTS": "TOTAL POINTS: %d",
	"SET_MASTER": "Master volume", "SET_SFX": "Effects volume", "SET_SENS": "Camera sensitivity",
	"SET_LANG": "Language", "BACK": "BACK",
	"CR_TITLE": "CREDITS", "CR_DEV": "Developer, Design & Production", "CR_DEV_NAME": "Hamed Najm",
	"CR_THANKS": "Special Thanks", "CR_FRIEND": "Khalid Younis",
	"CR_DEDICATION": "\"To my dear friend, thank you for being part of my life and for the brotherhood and love we share for the sake of Allah. I dedicate this work to you as a token of appreciation for our friendship. 🤍\"",
	"CR_ASSETS": "Third-party assets: see ASSET_CREDITS.md",
}

const _AR: Dictionary = {
	"MENU_ZOMBIES": "زومبيز", "MENU_SETTINGS": "الإعدادات", "MENU_CREDITS": "الطاقم والشكر", "MENU_EXIT": "خروج",
	"HUD_ROUND": "الجولة %d", "HUD_ZOMBIES": "الزومبي  %d", "HUD_POINTS": "النقاط  %d",
	"HUD_FIRE": "نار", "HUD_RELOAD": "تلقيم", "HUD_SWITCH": "تبديل", "HUD_USE": "تفاعل",
	"W_PISTOL": "مسدس", "W_SMG": "رشاش", "W_RIFLE": "بندقية", "W_SHOTGUN": "شوتغن", "W_SNIPER": "قناصة",
	"P_DOOR": "فتح الباب  [%d]", "P_BUY": "شراء  %s  [%d]", "P_AMMO": "شراء ذخيرة  %s  [%d]",
	"P_PERK": "%s  [%d]", "P_BOX": "صندوق الغموض  [%d]", "P_TAKE": "خذ  %s",
	"P_POWER": "شغّل الكهرباء", "P_NEED_POWER": "تحتاج الكهرباء", "P_TELEPORT": "انتقال  [%d]",
	"P_RETURN": "رجوع", "P_PAP": "تطوير السلاح  %s  [%d]", "P_PAP_DONE": "السلاح مطوَّر بالفعل",
	"P_OWNED": "%s مملوكة",
	"M_GET_READY": "استعد", "M_ROUND": "الجولة %d", "M_ROUND_DONE": "نجوت من الجولة %d",
	"M_NO_POINTS": "النقاط غير كافية", "M_POWER_ON": "الكهرباء تعمل", "M_PERK_GOT": "حصلت على %s",
	"M_REVIVED": "عدت للحياة", "M_UPGRADED": "تم تطوير السلاح", "M_TELEPORT": "جاري الانتقال",
	"M_DOOR_OPEN": "تم فتح الباب", "S_RETURN": "رجوع بعد %d",
	"PERK_JUGGERNOG": "قوة إضافية", "PERK_SPEED_COLA": "تلقيم سريع", "PERK_DOUBLE_TAP": "سرعة الإطلاق",
	"PERK_QUICK_REVIVE": "الإحياء السريع", "PERK_STAMIN_UP": "التحمّل", "PERK_DEADSHOT": "دقة القنّاص", "PERK_MULE_KICK": "سلاح ثالث",
	"PAUSE": "إيقاف مؤقت", "RESUME": "متابعة", "RESTART": "إعادة اللعب", "SETTINGS": "الإعدادات", "MAIN_MENU": "القائمة الرئيسية",
	"OVER_TITLE": "لقد قُضي عليك", "OVER_ROUND": "الجولة الأخيرة: %d", "OVER_POINTS": "مجموع النقاط: %d",
	"SET_MASTER": "الصوت العام", "SET_SFX": "المؤثرات الصوتية", "SET_SENS": "حساسية الكاميرا",
	"SET_LANG": "اللغة", "BACK": "رجوع",
	"CR_TITLE": "الطاقم والشكر", "CR_DEV": "المطور والتصميم والإنتاج", "CR_DEV_NAME": "حامد نجم",
	"CR_THANKS": "شكر خاص", "CR_FRIEND": "خالد يونس",
	"CR_DEDICATION": "«إلى صديقي العزيز، شكرًا لوجودك بحياتي، وللأخوّة والمحبّة في الله. هذا العمل أهديه إلك تقديرًا لصداقتنا. 🤍»",
	"CR_ASSETS": "الأصول الخارجية: راجع ASSET_CREDITS.md",
}
