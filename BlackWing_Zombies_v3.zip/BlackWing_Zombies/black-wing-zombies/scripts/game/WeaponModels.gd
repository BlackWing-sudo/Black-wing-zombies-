extends RefCounted
## Builds the blocky weapon models (pointing toward -Z).
## style 0 = normal, 1 = Pack-a-Punched (glowing purple), 2 = chalk outline (wall buys)


static func fill(model: Node3D, weapon_id: String, style: int) -> void:
	var metal: StandardMaterial3D
	var dark: StandardMaterial3D
	var wood: StandardMaterial3D
	var olive: StandardMaterial3D

	if style == 2:
		var chalk := StandardMaterial3D.new()
		chalk.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		chalk.albedo_color = Color(0.93, 0.93, 0.86)
		metal = chalk
		dark = chalk
		wood = chalk
		olive = chalk
	elif style == 1:
		metal = _mat(Color(0.3, 0.1, 0.55), 0.6, 0.35, Color(0.45, 0.1, 0.9), 0.7)
		dark = _mat(Color(0.12, 0.04, 0.25), 0.4, 0.5, Color(0.2, 0.05, 0.4), 0.5)
		wood = _mat(Color(0.1, 0.6, 0.7), 0.2, 0.4, Color(0.1, 0.8, 0.9), 0.8)
		olive = _mat(Color(0.35, 0.12, 0.6), 0.3, 0.4, Color(0.5, 0.15, 0.9), 0.6)
	else:
		metal = _mat(Color(0.14, 0.14, 0.16), 0.6, 0.45, Color.BLACK, 0.0)
		dark = _mat(Color(0.06, 0.06, 0.07), 0.3, 0.7, Color.BLACK, 0.0)
		wood = _mat(Color(0.34, 0.21, 0.11), 0.0, 0.85, Color.BLACK, 0.0)
		olive = _mat(Color(0.2, 0.26, 0.16), 0.2, 0.7, Color.BLACK, 0.0)

	match weapon_id:
		"PISTOL":
			_box(model, Vector3(0.05, 0.07, 0.26), Vector3(0.0, 0.0, -0.13), metal)
			_box(model, Vector3(0.045, 0.11, 0.06), Vector3(0.0, -0.085, -0.02), dark, 12.0)
			_box(model, Vector3(0.02, 0.025, 0.03), Vector3(0.0, 0.045, -0.24), dark)
		"SMG":
			_box(model, Vector3(0.06, 0.09, 0.36), Vector3(0.0, 0.0, -0.18), metal)
			_box(model, Vector3(0.025, 0.025, 0.16), Vector3(0.0, 0.01, -0.44), dark)
			_box(model, Vector3(0.04, 0.16, 0.05), Vector3(0.0, -0.12, -0.2), dark)
			_box(model, Vector3(0.04, 0.1, 0.05), Vector3(0.0, -0.09, -0.02), dark, 12.0)
			_box(model, Vector3(0.04, 0.06, 0.18), Vector3(0.0, 0.0, 0.1), dark)
		"RIFLE":
			_box(model, Vector3(0.06, 0.1, 0.5), Vector3(0.0, 0.0, -0.2), metal)
			_box(model, Vector3(0.03, 0.03, 0.3), Vector3(0.0, 0.015, -0.6), dark)
			_box(model, Vector3(0.055, 0.07, 0.25), Vector3(0.0, -0.005, -0.45), olive)
			_box(model, Vector3(0.05, 0.12, 0.25), Vector3(0.0, -0.02, 0.18), wood)
			_box(model, Vector3(0.045, 0.15, 0.08), Vector3(0.0, -0.13, -0.2), dark, -15.0)
			_box(model, Vector3(0.04, 0.1, 0.05), Vector3(0.0, -0.09, 0.0), dark, 12.0)
			_box(model, Vector3(0.02, 0.05, 0.04), Vector3(0.0, 0.075, -0.1), dark)
		"SHOTGUN":
			_box(model, Vector3(0.045, 0.045, 0.7), Vector3(0.0, 0.02, -0.38), metal)
			_box(model, Vector3(0.04, 0.04, 0.5), Vector3(0.0, -0.03, -0.3), dark)
			_box(model, Vector3(0.06, 0.1, 0.25), Vector3(0.0, 0.0, -0.05), metal)
			_box(model, Vector3(0.05, 0.1, 0.28), Vector3(0.0, -0.03, 0.2), wood)
			_box(model, Vector3(0.06, 0.06, 0.18), Vector3(0.0, -0.035, -0.42), wood)
		"SNIPER":
			_box(model, Vector3(0.03, 0.03, 0.8), Vector3(0.0, 0.02, -0.52), dark)
			_box(model, Vector3(0.06, 0.1, 0.45), Vector3(0.0, 0.0, -0.1), olive)
			_box(model, Vector3(0.045, 0.045, 0.22), Vector3(0.0, 0.095, -0.15), dark)
			_box(model, Vector3(0.05, 0.12, 0.3), Vector3(0.0, -0.02, 0.25), olive)
			_box(model, Vector3(0.04, 0.08, 0.05), Vector3(0.0, -0.09, -0.12), dark, -10.0)
		_:
			_box(model, Vector3(0.05, 0.08, 0.4), Vector3(0.0, 0.0, -0.2), metal)


static func _mat(color: Color, metallic: float, roughness: float, emission: Color, emission_energy: float) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.metallic = metallic
	m.roughness = roughness
	if emission_energy > 0.0:
		m.emission_enabled = true
		m.emission = emission
		m.emission_energy_multiplier = emission_energy
	return m


static func _box(parent: Node3D, box_size: Vector3, pos: Vector3, mat: Material, rot_x_deg: float = 0.0) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = box_size
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	mi.rotation_degrees.x = rot_x_deg
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi
