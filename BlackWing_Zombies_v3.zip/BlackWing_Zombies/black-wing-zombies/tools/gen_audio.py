import wave
import numpy as np

SR = 22050
OUT = "/home/claude/work/BlackWing_Zombies/black-wing-zombies/assets/audio/"
rng = np.random.default_rng(7)


def t_axis(dur):
    return np.arange(int(SR * dur)) / SR


def lowpass(x, alpha):
    y = np.zeros_like(x)
    acc = 0.0
    for i in range(len(x)):
        acc += alpha * (x[i] - acc)
        y[i] = acc
    return y


def noise(n):
    return rng.uniform(-1.0, 1.0, n)


def save(name, x, peak=0.85):
    m = float(np.max(np.abs(x)))
    if m > 0:
        x = x / m * peak
    # tiny fade out to avoid clicks
    fade = min(200, len(x))
    x[-fade:] *= np.linspace(1.0, 0.0, fade)
    data = (np.clip(x, -1, 1) * 32767).astype("<i2")
    with wave.open(OUT + name + ".wav", "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(data.tobytes())
    print(name, len(x) / SR, "s")


def gunshot(name, dur, noise_tau, noise_lp, thump_f, thump_tau, thump_gain, tail=0.0):
    t = t_axis(dur)
    n = lowpass(noise(len(t)), noise_lp) * np.exp(-t / noise_tau)
    thump = np.sin(2 * np.pi * (thump_f * np.exp(-t * 8) + thump_f * 0.4) * t) * np.exp(-t / thump_tau) * thump_gain
    crack = noise(len(t)) * np.exp(-t / 0.004) * 0.6
    x = n + thump + crack
    if tail > 0:
        x += lowpass(noise(len(t)), 0.05) * np.exp(-t / tail) * 0.25
    save(name, x)


def click(t, at, f, tau, gain=1.0):
    seg = np.zeros_like(t)
    m = t >= at
    tt = t[m] - at
    seg[m] = (np.sin(2 * np.pi * f * tt) * 0.6 + noise(len(tt)) * 0.5) * np.exp(-tt / tau) * gain
    return seg


def groan(name, dur, f_start, f_end, vib, noise_gain, harmonics=6):
    t = t_axis(dur)
    f = np.linspace(f_start, f_end, len(t)) * (1 + 0.12 * np.sin(2 * np.pi * vib * t))
    phase = 2 * np.pi * np.cumsum(f) / SR
    x = np.zeros_like(t)
    for k in range(1, harmonics + 1):
        x += np.sin(k * phase) / k
    x += lowpass(noise(len(t)), 0.2) * noise_gain
    env = np.sin(np.pi * t / dur) ** 0.7
    x = lowpass(x * env, 0.35)
    save(name, x, 0.7)


# --- weapons --------------------------------------------------------------
gunshot("shot_pistol", 0.30, 0.05, 0.5, 160, 0.06, 0.8, tail=0.08)
gunshot("shot_smg", 0.18, 0.035, 0.55, 190, 0.04, 0.6, tail=0.04)
gunshot("shot_rifle", 0.35, 0.07, 0.45, 130, 0.08, 0.9, tail=0.12)
gunshot("shot_shotgun", 0.60, 0.12, 0.35, 90, 0.16, 1.1, tail=0.25)
gunshot("shot_sniper", 0.90, 0.10, 0.3, 70, 0.22, 1.2, tail=0.4)

# reload: click - slide - click
t = t_axis(0.9)
x = click(t, 0.08, 1800, 0.012, 0.9) + click(t, 0.38, 900, 0.03, 0.7) + click(t, 0.72, 2200, 0.010, 1.0)
save("reload", x)

# empty trigger click
t = t_axis(0.12)
save("empty", click(t, 0.005, 2500, 0.012, 1.0))

# --- zombies / player -----------------------------------------------------
t = t_axis(0.18)
x = np.sin(2 * np.pi * (140 * np.exp(-t * 10) + 50) * t) * np.exp(-t / 0.05) + lowpass(noise(len(t)), 0.3) * np.exp(-t / 0.03) * 0.6
save("zombie_hit", x)

groan("zombie_die", 0.85, 130, 55, 6, 0.25)
groan("zombie_groan", 1.1, 85, 120, 4, 0.18)

t = t_axis(0.3)
f = np.linspace(210, 110, len(t))
x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.12) + lowpass(noise(len(t)), 0.3) * np.exp(-t / 0.05) * 0.5
save("player_hurt", x)

# round start: low horn
t = t_axis(1.4)
x = (np.sin(2 * np.pi * 82 * t) + 0.6 * np.sin(2 * np.pi * 123 * t) + 0.3 * np.sin(2 * np.pi * 164 * t)) * np.sin(np.pi * t / 1.4) ** 1.5
save("round_start", x, 0.7)

# --- new interaction sounds -------------------------------------------------
t = t_axis(1.1)
x = lowpass(noise(len(t)), 0.04) * 1.2 * np.sin(np.pi * t / 1.1) ** 0.5 + lowpass(noise(len(t)), 0.3) * 0.25 * np.sin(np.pi * t / 1.1)
x += click(t, 1.0, 120, 0.05, 1.5)
save("door_open", x)

t = t_axis(0.5)
x = np.sin(2 * np.pi * 1320 * t) * np.exp(-t / 0.08) + np.sin(2 * np.pi * 1980 * np.maximum(t - 0.09, 0)) * (t > 0.09) * np.exp(-(t - 0.09) / 0.15)
save("buy", x)

t = t_axis(0.6)
x = np.zeros_like(t)
for i, f0 in enumerate([523, 659, 784, 1047]):
    m = t >= i * 0.1
    tt = t[m] - i * 0.1
    x[m] += np.sin(2 * np.pi * f0 * tt) * np.exp(-tt / 0.12)
save("perk", x)

t = t_axis(1.2)
f = np.linspace(150, 1800, len(t))
x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.sin(np.pi * t / 1.2) + lowpass(noise(len(t)), 0.2) * 0.3 * np.sin(np.pi * t / 1.2)
save("teleport", x)

t = t_axis(1.3)
f = np.linspace(55, 220, len(t))
x = np.sin(2 * np.pi * np.cumsum(f) / SR) * (1 - np.exp(-t / 0.5)) + click(t, 0.05, 90, 0.08, 2.0)
save("power_on", x)
