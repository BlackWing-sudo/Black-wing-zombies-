OUT = "/home/claude/work/BlackWing_Zombies/black-wing-zombies/scenes/maps/ZombieMap.tscn"
T = 0.4
GAP = 3.4
WH = 4.5


def f(v):
    return "%g" % v


def tr(x, y, z):
    return "Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, %s, %s, %s)" % (f(x), f(y), f(z))


MATS = {
    "floor_start": (0.17, 0.18, 0.2), "floor_hall": (0.2, 0.19, 0.18), "floor_control": (0.14, 0.18, 0.16),
    "floor_garage": (0.2, 0.17, 0.15), "floor_yard": (0.15, 0.15, 0.17), "floor_lab": (0.22, 0.23, 0.24),
    "floor_storage": (0.18, 0.15, 0.12), "floor_court": (0.16, 0.17, 0.17),
    "wall_start": (0.34, 0.34, 0.37), "wall_hall": (0.4, 0.37, 0.33), "wall_control": (0.28, 0.36, 0.32),
    "wall_garage": (0.42, 0.3, 0.22), "wall_yard": (0.26, 0.26, 0.3), "wall_lab": (0.5, 0.52, 0.54),
    "wall_storage": (0.36, 0.28, 0.2), "wall_court": (0.3, 0.32, 0.32),
    "crate": (0.38, 0.27, 0.16), "barrier": (0.46, 0.46, 0.43), "column": (0.3, 0.3, 0.33), "car": (0.28, 0.14, 0.1),
    "table": (0.25, 0.25, 0.28), "pap": (0.18, 0.1, 0.28),
}

subs, sub_ids, nodes, exts = [], {}, [], {}


def sub_res(kind, props, key):
    k = (kind, key)
    if k in sub_ids:
        return sub_ids[k]
    sid = "%s_%d" % (kind, len(sub_ids) + 1)
    sub_ids[k] = sid
    subs.append("\n".join(['[sub_resource type="%s" id="%s"]' % (kind, sid)] + ["%s = %s" % (a, b) for a, b in props]))
    return sid


def mat_id(name):
    r, g, b = MATS[name]
    return sub_res("StandardMaterial3D", [("albedo_color", "Color(%s, %s, %s, 1)" % (f(r), f(g), f(b))), ("roughness", "0.95")], name)


def group(name, parent):
    nodes.append('[node name="%s" type="Node3D" parent="%s"]' % (name, parent))


def box(parent, name, size, pos, mat):
    sx, sy, sz = size
    v = "Vector3(%s, %s, %s)" % (f(sx), f(sy), f(sz))
    m = sub_res("BoxMesh", [("size", v)], size)
    s = sub_res("BoxShape3D", [("size", v)], size)
    nodes.append('[node name="%s" type="StaticBody3D" parent="%s"]\ntransform = %s' % (name, parent, tr(*pos)))
    nodes.append('[node name="Mesh" type="MeshInstance3D" parent="%s/%s"]\nmaterial_override = SubResource("%s")\nmesh = SubResource("%s")' % (parent, name, mat_id(mat), m))
    nodes.append('[node name="Collision" type="CollisionShape3D" parent="%s/%s"]\nshape = SubResource("%s")' % (parent, name, s))


def segments(a0, a1, gaps):
    pts, cur = [], a0
    for g in sorted(gaps):
        pts.append((cur, g - GAP / 2))
        cur = g + GAP / 2
    pts.append((cur, a1))
    return [(x0, x1) for x0, x1 in pts if x1 - x0 > 0.05]


def hwall(parent, name, z, x0, x1, gaps, mat):
    for i, (a, b) in enumerate(segments(x0 - 0.2, x1 + 0.2, gaps)):
        box(parent, "%s_%d" % (name, i), (b - a, WH, T), ((a + b) / 2, WH / 2, z), mat)


def vwall(parent, name, x, z0, z1, gaps, mat):
    for i, (a, b) in enumerate(segments(z0 - 0.2, z1 + 0.2, gaps)):
        box(parent, "%s_%d" % (name, i), (T, WH, b - a), (x, WH / 2, (a + b) / 2), mat)


def ext(key, path, kind="Script"):
    exts[key] = (kind, path)
    return key


E_PLAYER = "1_player"
exts[E_PLAYER] = ("PackedScene", "res://scenes/player/Player.tscn", "uid://bq4t0oio8ykgv")
S = {k: ext("s_" + k, "res://scripts/%s.gd" % p) for k, p in {
    "combat": "player/PlayerCombat", "mode": "game/ZombieMode", "hud": "ui/ZombieHUD", "interactor": "game/Interactor",
    "door": "game/BuyDoor", "wall": "game/WallBuy", "perk": "game/PerkMachine", "box": "game/MysteryBox",
    "power": "game/PowerSwitch", "tele": "game/Teleporter", "pap": "game/PackAPunch"}.items()}

# ---------------------------------------------------------------- level geometry
group("Level", "NavRegion")
L = "NavRegion/Level"
ZONES = {  # name: (x0, x1, z0, z1)
    "start": (-18, 18, -8, 16), "hall": (-14, 14, -32, -8), "control": (-12, 12, -50, -32),
    "garage": (18, 50, -8, 16), "yard": (50, 80, -12, 20), "lab": (-50, -18, -8, 16),
    "storage": (-80, -50, -12, 20), "court": (-16, 16, 16, 42)}
group("Floors", L)
for n, (x0, x1, z0, z1) in ZONES.items():
    box(L + "/Floors", "Floor_" + n, (x1 - x0, 0.4, z1 - z0), ((x0 + x1) / 2, -0.2, (z0 + z1) / 2), "floor_" + n)

group("Walls", L)
W = L + "/Walls"
hwall(W, "N_Start", -8, -50, 50, [0], "wall_start")
hwall(W, "S_Start", 16, -50, 50, [0], "wall_start")
vwall(W, "W_Start", -18, -8, 16, [4], "wall_start")
vwall(W, "E_Start", 18, -8, 16, [4], "wall_garage")
vwall(W, "W_Hall", -14, -32, -8, [], "wall_hall")
vwall(W, "E_Hall", 14, -32, -8, [], "wall_hall")
hwall(W, "N_Hall", -32, -14, 14, [0], "wall_hall")
vwall(W, "W_Ctl", -12, -50, -32, [], "wall_control")
vwall(W, "E_Ctl", 12, -50, -32, [], "wall_control")
hwall(W, "N_Ctl", -50, -12, 12, [], "wall_control")
vwall(W, "E_Garage", 50, -12, 20, [4], "wall_garage")
vwall(W, "W_Lab", -50, -12, 20, [4], "wall_lab")
hwall(W, "N_Yard", -12, 50, 80, [], "wall_yard")
hwall(W, "S_Yard", 20, 50, 80, [], "wall_yard")
vwall(W, "E_Yard", 80, -12, 20, [], "wall_yard")
hwall(W, "N_Stor", -12, -80, -50, [], "wall_storage")
hwall(W, "S_Stor", 20, -80, -50, [], "wall_storage")
vwall(W, "W_Stor", -80, -12, 20, [], "wall_storage")
vwall(W, "W_Court", -16, 16, 42, [], "wall_court")
vwall(W, "E_Court", 16, 16, 42, [], "wall_court")
hwall(W, "S_Court", 42, -16, 16, [], "wall_court")

group("Cover", L)
C = L + "/Cover"
props = [
    # start
    ("Crate", (1.2, 1.2, 1.2), (-12, 0.6, -4), "crate"), ("Crate", (1.2, 1.2, 1.2), (-10.8, 0.6, -4), "crate"), ("Crate", (1.2, 1.2, 1.2), (-11.4, 1.8, -4), "crate"),
    ("Barrier", (4, 1, 0.5), (8, 0.5, 0), "barrier"), ("Pillar", (1, 3.5, 1), (-8, 1.75, 6), "column"), ("Pillar", (1, 3.5, 1), (8, 1.75, 6), "column"),
    ("Crate", (1.2, 1.2, 1.2), (13, 0.6, 12), "crate"), ("Crate", (1.2, 1.2, 1.2), (14.3, 0.6, 12.4), "crate"), ("Barrier", (0.5, 1, 4), (-13, 0.5, 10), "barrier"),
    ("Wreck", (4.2, 1.2, 1.8), (12, 0.6, -4), "car"),
    # hall
    ("Pillar", (1, 3.5, 1), (-6, 1.75, -14), "column"), ("Pillar", (1, 3.5, 1), (6, 1.75, -14), "column"),
    ("Pillar", (1, 3.5, 1), (-6, 1.75, -26), "column"), ("Pillar", (1, 3.5, 1), (6, 1.75, -26), "column"),
    ("Table", (4.5, 1, 1.2), (0, 0.5, -20), "table"), ("Crate", (1.2, 1.2, 1.2), (10, 0.6, -12), "crate"), ("Crate", (1.2, 1.2, 1.2), (11.3, 0.6, -12), "crate"),
    ("Barrier", (3.2, 1, 0.5), (-9, 0.5, -10.5), "barrier"),
    # control
    ("Desk", (3, 1, 1), (-5, 0.5, -37), "table"), ("Desk", (3, 1, 1), (5, 0.5, -37), "table"), ("Pillar", (1, 3.5, 1), (8, 1.75, -43), "column"), ("Crate", (1.2, 1.2, 1.2), (-8, 0.6, -46), "crate"),
    # garage
    ("Wreck", (4.2, 1.2, 1.8), (26, 0.6, -3), "car"), ("Wreck", (1.8, 1.2, 4.2), (40, 0.6, 9), "car"), ("Crate", (1.2, 1.2, 1.2), (44, 0.6, -4), "crate"),
    ("Crate", (1.2, 1.2, 1.2), (45.3, 0.6, -4), "crate"), ("Barrier", (4, 1, 0.5), (34, 0.5, 5), "barrier"), ("Pillar", (1, 3.5, 1), (42, 1.75, 2), "column"),
    # yard east
    ("Crate", (1.2, 1.2, 1.2), (56, 0.6, 16), "crate"), ("Crate", (1.2, 1.2, 1.2), (57.3, 0.6, 16), "crate"), ("Barrier", (4, 1, 0.5), (68, 0.5, 12), "barrier"),
    ("Barrier", (0.5, 1, 4), (72, 0.5, -6), "barrier"), ("Pillar", (1, 3.5, 1), (62, 1.75, 4), "column"), ("Pillar", (1, 3.5, 1), (72, 1.75, 4), "column"),
    # lab
    ("Table", (5, 1, 1.2), (-40, 0.5, 0), "table"), ("Table", (1.2, 1, 5), (-24, 0.5, 8), "table"), ("Pillar", (1, 3.5, 1), (-26, 1.75, -2), "column"),
    ("Pillar", (1, 3.5, 1), (-42, 1.75, 10), "column"), ("Crate", (1.2, 1.2, 1.2), (-46, 0.6, -4), "crate"), ("Crate", (1.2, 1.2, 1.2), (-44.7, 0.6, -4), "crate"),
    # storage
    ("Crate", (1.2, 1.2, 1.2), (-70, 0.6, -8), "crate"), ("Crate", (1.2, 1.2, 1.2), (-68.7, 0.6, -8), "crate"), ("Crate", (1.2, 1.2, 1.2), (-69.35, 1.8, -8), "crate"),
    ("Crate", (1.2, 1.2, 1.2), (-60, 0.6, 16), "crate"), ("Crate", (1.2, 1.2, 1.2), (-58.7, 0.6, 16), "crate"), ("Barrier", (4, 1, 0.5), (-66, 0.5, 6), "barrier"),
    ("Pillar", (1, 3.5, 1), (-62, 1.75, -2), "column"), ("Pillar", (1, 3.5, 1), (-72, 1.75, 12), "column"),
    # courtyard
    ("Crate", (1.2, 1.2, 1.2), (8, 0.6, 22), "crate"), ("Crate", (1.2, 1.2, 1.2), (9.3, 0.6, 22), "crate"), ("Barrier", (3.2, 1, 0.5), (-8, 0.5, 24), "barrier"),
    ("Pillar", (1, 3.5, 1), (-8, 1.75, 36), "column"), ("Pillar", (1, 3.5, 1), (8, 1.75, 36), "column"), ("Barrier", (0.5, 1, 4), (10, 0.5, 32), "barrier"),
]
for i, (n, size, pos, mat) in enumerate(props):
    box(C, "%s_%d" % (n, i), size, pos, mat)

# ---------------------------------------------------------------- interactables (inside NavRegion so they carve the navmesh)
group("Props", "NavRegion")
P = "NavRegion/Props"


def inter(parent, name, kind, pos, props_txt):
    nodes.append('[node name="%s" type="Node3D" parent="%s"]\ntransform = %s\nscript = ExtResource("%s")\n%s' % (name, parent, tr(*pos), S[kind], props_txt))


for name, perk, pos, yaw in [
    ("Perk_Jugger", "JUGGERNOG", (-13.1, 0, -20), 90), ("Perk_Stamin", "STAMIN_UP", (-11.1, 0, -41), 90),
    ("Perk_Speed", "SPEED_COLA", (30, 0, 15.1), 180), ("Perk_DoubleTap", "DOUBLE_TAP", (-30, 0, -7.1), 0),
    ("Perk_Mule", "MULE_KICK", (79.1, 0, 4), -90), ("Perk_Revive", "QUICK_REVIVE", (-15.1, 0, 30), 90),
    ("Perk_Deadshot", "DEADSHOT", (-79.1, 0, 4), 90)]:
    inter(P, name, "perk", pos, 'yaw_deg = %s\nperk_id = "%s"' % (f(yaw), perk))
for name, wid, pos, yaw in [("Wall_SMG", "SMG", (-9, 1.8, -7.8), 0), ("Wall_Rifle", "RIFLE", (34, 1.8, -7.8), 0),
                            ("Wall_Shotgun", "SHOTGUN", (-34, 1.8, 15.8), 180), ("Wall_Sniper", "SNIPER", (-6, 1.8, 41.8), 180)]:
    inter(P, name, "wall", pos, 'yaw_deg = %s\nweapon_id = "%s"' % (f(yaw), wid))
inter(P, "MysteryBox", "box", (62, 0, -10.8), "yaw_deg = 0.0")
inter(P, "PowerSwitch", "power", (0, 0, -49), "yaw_deg = 0.0")
inter(P, "TeleporterPad", "tele", (0, 0, 30), 'kind = "pad"\ncost = 1500\nstay_time = 30.0')

# doors: OUTSIDE the nav region
group("Doors", ".")
for name, pos, yaw, cost, zone in [
    ("Door_Hall", (0, 0, -8), 0, 750, "hall"), ("Door_Court", (0, 0, 16), 0, 1000, "court"),
    ("Door_Lab", (-18, 0, 4), 90, 750, "lab"), ("Door_Garage", (18, 0, 4), 90, 750, "garage"),
    ("Door_Control", (0, 0, -32), 0, 1250, "control"), ("Door_Yard", (50, 0, 4), 90, 1500, "yard"),
    ("Door_Storage", (-50, 0, 4), 90, 1500, "storage")]:
    inter("Doors", name, "door", pos, 'yaw_deg = %s\ncost = %d\nopens_zones = PackedStringArray("%s")' % (f(yaw), cost, zone))

# ---------------------------------------------------------------- Pack-a-Punch room (far away, not navigated)
group("PapRoom", ".")
R = "PapRoom"
box(R, "Floor", (20, 0.4, 20), (200, -0.2, 0), "floor_lab")
for nm, size, pos in [("WallN", (20.4, 5, 0.4), (200, 2.5, -10)), ("WallS", (20.4, 5, 0.4), (200, 2.5, 10)),
                      ("WallW", (0.4, 5, 20.4), (190, 2.5, 0)), ("WallE", (0.4, 5, 20.4), (210, 2.5, 0))]:
    box(R, nm, size, pos, "pap")
inter(R, "PackAPunch", "pap", (200, 0, -8.8), "yaw_deg = 0.0")
inter(R, "ReturnPad", "tele", (205, 0, 4), 'kind = "return"\ncost = 0')
nodes.append('[node name="PapArrival" type="Marker3D" parent="PapRoom"]\ntransform = %s' % tr(195, 0.1, 4))
nodes.append('[node name="PadReturn" type="Marker3D" parent="."]\ntransform = %s' % tr(0, 0.1, 34))
nodes.append('[node name="PapLight" type="OmniLight3D" parent="PapRoom"]\ntransform = %s\nlight_color = Color(0.7, 0.4, 1, 1)\nlight_energy = 2.2\nomni_range = 18' % tr(200, 4, 0))

# ---------------------------------------------------------------- lights + spawns
LIGHTS = [("start", (0, 4, 4), (1, 0.85, 0.6)), ("hall", (0, 4, -20), (1, 0.55, 0.35)), ("control", (0, 4, -41), (0.5, 1, 0.7)),
          ("garage", (34, 4, 4), (1, 0.6, 0.4)), ("yard", (65, 4, 4), (0.6, 0.7, 1)), ("lab", (-34, 4, 4), (0.8, 0.9, 1)),
          ("storage", (-65, 4, 4), (1, 0.7, 0.4)), ("court", (0, 4, 29), (0.7, 0.9, 1))]
group("Lights", ".")
lamp_mesh = sub_res("BoxMesh", [("size", "Vector3(0.3, 0.1, 0.3)")], "lamp")
lamp_mat = sub_res("StandardMaterial3D", [("shading_mode", "0"), ("albedo_color", "Color(1, 0.9, 0.7, 1)")], "lampmat")
for n, pos, c in LIGHTS:
    nodes.append('[node name="Light_%s" type="OmniLight3D" parent="Lights"]\ntransform = %s\nlight_color = Color(%s, %s, %s, 1)\nlight_energy = 1.8\nomni_range = 18' % (n, tr(*pos), f(c[0]), f(c[1]), f(c[2])))
    nodes.append('[node name="Lamp_%s" type="MeshInstance3D" parent="Lights"]\ntransform = %s\nmaterial_override = SubResource("%s")\nmesh = SubResource("%s")' % (n, tr(pos[0], pos[1] + 0.3, pos[2]), lamp_mat, lamp_mesh))

SPAWNS = {
    "start": [(-15, 0, 0), (15, 0, 0), (-15, 0, 13), (15, 0, 14)],
    "hall": [(-10, 0, -28), (10, 0, -28), (10, 0, -17)],
    "control": [(-8, 0, -46), (8, 0, -47), (9, 0, -35)],
    "garage": [(22, 0, -4), (46, 0, 13), (22, 0, 13), (40, 0, -4)],
    "yard": [(76, 0, -8), (76, 0, 16), (55, 0, -8), (72, 0, 16)],
    "lab": [(-46, 0, 12), (-22, 0, -4), (-22, 0, 12), (-36, 0, -4)],
    "storage": [(-76, 0, -8), (-76, 0, 16), (-56, 0, -8), (-66, 0, 18)],
    "court": [(-12, 0, 38), (12, 0, 38), (-12, 0, 20), (13, 0, 20)]}
group("SpawnPoints", ".")
for z, pts in SPAWNS.items():
    for i, p in enumerate(pts):
        nodes.append('[node name="Sp_%s_%d" type="Marker3D" parent="SpawnPoints" groups=["zombie_spawn"]]\ntransform = %s\nmetadata/zone = "%s"' % (z, i, tr(*p), z))

# ---------------------------------------------------------------- environment / assembly
env = sub_res("Environment", [("background_mode", "1"), ("background_color", "Color(0.02, 0.025, 0.04, 1)"), ("ambient_light_source", "2"),
                              ("ambient_light_color", "Color(0.32, 0.36, 0.48, 1)"), ("ambient_light_energy", "1.0"), ("fog_enabled", "true"),
                              ("fog_light_color", "Color(0.06, 0.07, 0.1, 1)"), ("fog_density", "0.015")], "env")
nav = sub_res("NavigationMesh", [("geometry_parsed_geometry_type", "1"), ("cell_size", "0.3"), ("cell_height", "0.2"), ("agent_height", "1.8"),
                                 ("agent_radius", "0.6"), ("agent_max_climb", "0.2"), ("agent_max_slope", "45.0")], "nav")

head = ["[gd_scene format=3]", ""]
for k, v in exts.items():
    if len(v) == 3:
        head.append('[ext_resource type="%s" uid="%s" path="%s" id="%s"]' % (v[0], v[2], v[1], k))
    else:
        head.append('[ext_resource type="%s" path="%s" id="%s"]' % (v[0], v[1], k))
head.append("")

body = ['[node name="ZombieMap" type="Node3D"]',
        '[node name="WorldEnvironment" type="WorldEnvironment" parent="."]\nenvironment = SubResource("%s")' % env,
        '[node name="Moonlight" type="DirectionalLight3D" parent="."]\ntransform = Transform3D(0.8660254, 0.38302222, -0.32139382, 0, 0.64278764, 0.76604444, 0.5, -0.66341394, 0.5566704, 0, 5, 0)\nlight_color = Color(0.55, 0.65, 0.95, 1)\nlight_energy = 0.8',
        '[node name="NavRegion" type="NavigationRegion3D" parent="."]\nnavigation_mesh = SubResource("%s")' % nav]
body += nodes
body += ['[node name="Zombies" type="Node3D" parent="."]',
         '[node name="Player" parent="." instance=ExtResource("%s")]\ntransform = %s' % (E_PLAYER, tr(0, 0.1, 10)),
         '[node name="PlayerCombat" type="Node" parent="Player"]\nscript = ExtResource("%s")' % S["combat"],
         '[node name="MoveJoystick" type="VirtualJoystick" parent="."]\nanchors_preset = -1\nanchor_left = 0.12\nanchor_top = 0.74\nanchor_right = 0.12\nanchor_bottom = 0.74\noffset_left = -90.0\noffset_top = -90.0\noffset_right = 90.0\noffset_bottom = 90.0\ngrow_horizontal = 0\ngrow_vertical = 0\njoystick_size = 205.0\ntip_size = 135.0',
         '[node name="ZombieMode" type="Node" parent="."]\nscript = ExtResource("%s")' % S["mode"],
         '[node name="Interactor" type="Node" parent="."]\nscript = ExtResource("%s")' % S["interactor"],
         '[node name="ZombieHUD" type="CanvasLayer" parent="."]\nlayer = 5\nscript = ExtResource("%s")' % S["hud"]]
with open(OUT, "w", encoding="utf-8") as fh:
    fh.write("\n".join(head) + "\n" + "\n\n".join(subs) + "\n\n" + "\n\n".join(body) + "\n")
print("nodes", len(nodes), "subs", len(subs))
